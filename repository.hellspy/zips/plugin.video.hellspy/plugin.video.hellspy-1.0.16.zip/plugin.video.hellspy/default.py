import sys
import os
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import re
import hashlib
import unicodedata
from collections import defaultdict

# Dynamický import knihoven ze složky resources/lib
# Ponecháno pro zajištění kompatibility s externími knihovnami
lib_dir = xbmcvfs.translatePath("special://home/addons/plugin.video.hellspy/resources/lib")
sys.path.insert(0, lib_dir)

# IMPORTY po nastavení sys.path
import cloudscraper
import requests
from bs4 import BeautifulSoup

# === Cesty k souborům ===
history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/history.txt")
watch_history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history.txt")
cached_results_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/cache.json")
search_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/search_cache.json")
tmdb_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_cache.json")
tmdb_api_key_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_api.key")

# === TMDb Konfigurace ===
TMDB_BASE_URL = "https://api.themoviedb.org/3"

# === Načtení konfigurace z nastavení doplňku ===
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = 'https://www.hellspy.to'
results_per_page = int(addon.getSetting('results_per_page') or 64)
search_history_limit = int(addon.getSetting('search_history_limit') or 10)
watch_history_limit = int(addon.getSetting('watch_history_limit') or 20)

def read_cache(cache_file, key):
    """Načte data z cache souboru pro daný klíč."""
    try:
        if xbmcvfs.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            return cache.get(key)
    except Exception as e:
        log_debug(f"Chyba při čtení cache z {cache_file}: {e}")
    return None

def save_cache(cache_file, key, data):
    """Uloží data do cache souboru pro daný klíč."""
    try:
        cache = {}
        if xbmcvfs.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                try:
                    cache = json.load(f)
                except json.JSONDecodeError:
                    log_debug(f"Cache soubor {cache_file} je poškozený, vytvářím nový.")
                    cache = {}
        
        cache[key] = data
        
        # Omezení velikosti cache na 500 záznamů (nebo jiná hodnota)
        # Aby cache nerostla do nekonečna
        if len(cache) > 500:
            # Odstraníme nejstarší záznamy (náhodně, nebo podle nějakého řazení, zde náhodně)
            # Lepší by bylo třeba podle posledního přístupu, ale to vyžaduje složitější cache strukturu
            for _ in range(len(cache) - 400): # Ponecháme 400, odstraníme 100 nejstarších/náhodných
                cache.pop(next(iter(cache)))

        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=4)
    except Exception as e:
        log_debug(f"Chyba při ukládání cache do {cache_file}: {e}")

def _get_tmdb_api_key():
    """Načte TMDb API klíč ze souboru."""
    try:
        if xbmcvfs.exists(tmdb_api_key_file):
            with open(tmdb_api_key_file, "r", encoding="utf-8") as f:
                api_key = f.read().strip()
                if api_key:
                    log_debug("TMDb API klíč úspěšně načten ze souboru.")
                    return api_key
        log_debug(f"TMDb API klíč nebyl nalezen v souboru: {tmdb_api_key_file}. Ujistěte se, že soubor existuje a obsahuje klíč.")
    except Exception as e:
        log_debug(f"Chyba při načítání TMDb API klíče ze souboru: {e}")
    return None

def _get_tmdb_data(endpoint, params):
    """
    Provádí GET požadavek na TMDb API a ukládá/načítá data z cache.
    endpoint: např. '/search/multi'
    params: slovník parametrů pro API dotaz
    """
    tmdb_api_key = _get_tmdb_api_key()
    if not tmdb_api_key:
        log_debug("Nelze provést TMDb požadavek: API klíč není k dispozici.")
        return None

    # Vytvoření cache klíče z endpointu a parametrů
    cache_key = hashlib.md5(f"{endpoint}-{json.dumps(params, sort_keys=True)}".encode('utf-8')).hexdigest()
    
    # Zkusit načíst z cache
    cached_data = read_cache(tmdb_cache_file, cache_key)
    if cached_data:
        log_debug(f"Používám TMDb data z cache pro klíč: {cache_key}")
        return cached_data

    params['api_key'] = tmdb_api_key
    params['language'] = 'cs' # Preferujeme češtinu

    full_url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    
    log_debug(f"TMDb API požadavek: {full_url}")
    try:
        response = requests.get(full_url, timeout=10)
        response.raise_for_status() # Vyvolá HTTPError pro špatné odpovědi (4xx nebo 5xx)
        data = response.json()
        save_cache(tmdb_cache_file, cache_key, data) # Uložit do cache
        log_debug(f"TMDb data uložena do cache pro klíč: {cache_key}")
        return data
    except requests.exceptions.Timeout:
        log_debug("TMDb API požadavek vypršel (timeout).")
    except requests.exceptions.RequestException as e:
        log_debug(f"Chyba při TMDb API požadavku: {e}")
    except json.JSONDecodeError as e:
        log_debug(f"Chyba při dekódování TMDb JSON odpovědi: {e}")
    return None

def search_tmdb(query_text):
    """
    Vyhledá film nebo seriál na TMDb a vrátí relevantní data.
    Pokusí se najít shodu a vrátí kanonický název a ID.
    """
    log_debug(f"Hledám na TMDb pro dotaz: '{query_text}'")
    params = {'query': query_text}
    data = _get_tmdb_data('/search/multi', params) # multi-search pro filmy i seriály

    if not data or 'results' not in data:
        return None

    best_match = None
    for result in data['results']:
        if result['media_type'] == 'movie':
            # Zkusíme najít film s českým názvem nebo originálním
            title = result.get('title') or result.get('original_title')
            release_date = result.get('release_date', '')
            year = release_date.split('-')[0] if release_date else ''
            
            # Preferujeme výsledky, které mají nějaký rok v názvu, pokud query obsahuje rok
            # nebo pokud se název shoduje přesněji
            
            # Prozatím jednoduchá heuristika: prvni film nebo TV pořad
            if not best_match: # Vezmeme první shodu, můžeme vylepšit později
                best_match = {
                    'type': 'movie',
                    'tmdb_id': result['id'],
                    'title': result.get('title') or result.get('original_title'),
                    'year': year,
                    'poster': result.get('poster_path'),
                    'overview': result.get('overview')
                }
                # Zkusíme najít česky lokalizovaný název, pokud existuje
                if 'original_language' in result and result['original_language'] != 'cs':
                    # Někdy TMDb vrací titles v default jazyce a overview lokalizované.
                    # Můžeme zkusit zavolat specifický endpoint pro detaily s language='cs'
                    # Prozatím se spolehneme na to, co vrátí multi-search s language='cs' parametrem.
                    pass 
                break # Vezmeme první shodu, můžeme vylepšit logiku později

        elif result['media_type'] == 'tv':
            # Zkusíme najít TV seriál s českým názvem nebo originálním
            name = result.get('name') or result.get('original_name')
            first_air_date = result.get('first_air_date', '')
            year = first_air_date.split('-')[0] if first_air_date else ''

            if not best_match: # Vezmeme první shodu
                best_match = {
                    'type': 'tv',
                    'tmdb_id': result['id'],
                    'title': name,
                    'year': year,
                    'poster': result.get('poster_path'),
                    'overview': result.get('overview')
                }
                break # Vezmeme první shodu, můžeme vylepšit logiku později
    
    if best_match:
        log_debug(f"Nalezen nejlepší TMDb shoda pro '{query_text}': {best_match['title']} ({best_match['type']})")
    else:
        log_debug(f"Nenalezena žádná vhodná TMDb shoda pro '{query_text}'.")
    
    return best_match

def log_debug(message):
    """Zjednodušená funkce pro logování ladicích zpráv."""
    xbmc.log(f"[Hellspy DEBUG] {message}", xbmc.LOGINFO)

# --- Funkce pro správu historie hledání ---
def save_query_to_history(query, results_count):
    """Uloží hledaný dotaz a počet výsledků do historie."""
    try:
        history_dir = os.path.dirname(history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        history = load_query_history()
        entry = f"{query}|{results_count}"
        # Odstraní starší záznamy stejného dotazu
        history = [h for h in history if not h.startswith(f"{query}|")]
        history.insert(0, entry) # Přidá na začátek
        history = history[:search_history_limit] # Omezí počet záznamů
        with open(history_file, "w", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
            f.write("\n".join(history))
        log_debug(f"Dotaz '{query}' uložen do historie s {results_count} výsledky.")
    except Exception as e:
        log_debug(f"Chyba při zápisu do historie hledání: {e}")

def load_query_history():
    """Načte historii hledání."""
    try:
        if xbmcvfs.exists(history_file):
            with open(history_file, "r", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
                return [line.strip() for line in f if line.strip()]
    except Exception as e:
        log_debug(f"Chyba při načítání historie hledání: {e}")
    return []

def delete_query_from_history(query):
    """Smaže konkrétní dotaz z historie hledání."""
    try:
        history = load_query_history()
        history = [h for h in history if not h.startswith(f"{query}|")]
        with open(history_file, "w", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
            f.write("\n".join(history))
        log_debug(f"Dotaz '{query}' smazán z historie hledání.")
    except Exception as e:
        log_debug(f"Chyba při mazání z historie hledání: {e}")

# --- Funkce pro správu historie sledování ---
def save_watch_history_entry(video_page_url, title):
    """Uloží záznam o sledovaném videu do historie sledování."""
    try:
        parsed = urllib.parse.urlparse(video_page_url)
        parts = parsed.path.split('/')
        if len(parts) >= 4 and parts[1] == "video":
            video_id = f"{parts[2]}/{parts[3]}"
        else:
            log_debug(f"Chybný formát URL pro uložení do historie sledování: {video_page_url}")
            return

        # Před uložením normalizovat titulek
        # Toto zajistí, že všechny tituly jsou uloženy v konzistentní Unicode formě.
        title = unicodedata.normalize('NFC', title)
        log_debug(f"Normalizovaný název před uložením do historie: '{title}'")

        history_dir = os.path.dirname(watch_history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)

        existing = []
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                existing = [line.strip() for line in f if line.strip()]

        entry = f"{video_id}|{title}"
        existing = [e for e in existing if not e.startswith(video_id)]
        existing.insert(0, entry)
        existing = existing[:watch_history_limit]

        with open(watch_history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(existing))
        log_debug(f"Video '{title}' ({video_id}) uloženo do historie sledování.")
    except Exception as e:
        log_debug(f"Chyba při ukládání historie sledování: {e}")

def load_watch_history_list():
    """Načte historii sledování a pokusí se opravit problémy s kódováním."""
    history_list = []
    try:
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if '|' in line:
                        parts = line.split('|', 1)
                        if len(parts) == 2:
                            video_id, title = parts

                            original_title = title # Pro debug
                            # Pokus o opravu Mojibake:
                            # 1. Zkusit, jestli to není UTF-8 dekódované jako Latin-1
                            try:
                                corrected_title = title.encode('latin1').decode('utf-8')
                                # Jednoduchá heuristika: pokud původní obsahuje 'Å' nebo 'Ã' a opravená ne
                                if ('Å' in title or 'Ã' in title) and ('Å' not in corrected_title and 'Ã' not in corrected_title):
                                    title = corrected_title
                                    log_debug(f"Opraven název v historii (Latin-1->UTF-8): '{original_title}' -> '{title}'")
                            except (UnicodeEncodeError, UnicodeDecodeError):
                                pass # Nepodařilo se opravit, zkusíme další možnosti
                            except Exception as e:
                                log_debug(f"Neočekávaná chyba při korekci názvu 1 v load_watch_history_list: {e}")

                            # 2. Zkusit normalizovat na NFD a pak NFC, pokud by byly složené znaky
                            try:
                                normalized_title = unicodedata.normalize('NFC', title)
                                if normalized_title != title:
                                    log_debug(f"Normalizován název v historii (NFC): '{title}' -> '{normalized_title}'")
                                    title = normalized_title
                            except Exception as e:
                                log_debug(f"Chyba při normalizaci názvu v load_watch_history_list: {e}")

                            history_list.append([video_id, title])
                        else:
                            log_debug(f"Nepravidelný záznam v historii sledování: {line}")
    except Exception as e:
        log_debug(f"Chyba při načítání historie sledování: {e}")
    return history_list

def list_watch_history():
    """Zobrazí historii sledování v Kodi."""
    history = load_watch_history_list()
    if not history:
        xbmcgui.Dialog().ok("Historie sledování", "Historie sledování je prázdná.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    for video_id, title in history:
        play_url = build_url({'mode': 'play', 'url': f"{base_url}/video/{video_id}"})
        li = xbmcgui.ListItem(label=title)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def build_url(query):
    """Sestaví URL pro volání funkcí pluginu."""
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def get_html(url):
    """Získá HTML obsah z dané URL pomocí cloudscraperu."""
    scraper = cloudscraper.create_scraper()
    try:
        response = scraper.get(url, timeout=10)
        response.raise_for_status()  # Vyvolá chybu pro špatné status kódy
        log_debug(f"GET {url} → Status {response.status_code}")
        # Zajistíme, že response.text je dekódováno jako UTF-8
        # requests se obvykle snaží uhodnout kódování, ale explicitní nastavení je bezpečnější
        response.encoding = 'utf-8' 
        return response.text
    except requests.exceptions.RequestException as e:
        log_debug(f"Chyba při spojení s {url}: {e}")
        xbmcgui.Dialog().ok("Chyba připojení", "Nepodařilo se spojit se serverem Hellspy.\nZkontrolujte připojení k internetu a zkuste to znovu.")
        raise
    except Exception as e:
        log_debug(f"Neočekávaná chyba v get_html: {e}")
        xbmcgui.Dialog().ok("Chyba", "Došlo k neočekávané chybě při získávání obsahu.")
        raise

def remove_diacritics(text):
    if not isinstance(text, str):
        return text # Vrátí nezměněné, pokud to není string
    normalized_text = unicodedata.normalize('NFD', text)
    stripped_text = ''.join(char for char in normalized_text if unicodedata.category(char) != 'Mn')
    return str(stripped_text)

def extract_episode_info(title):
    """
    Extrahování informací o sezóně a epizodě z názvu.
    Vylepšeno pro robustnější chování a prioritizaci "série/díl" formátů
    a zajištění odstranění diakritiky z názvu.
    """
    original_title = title
    log_debug(f"Vstupní název pro extrakci epizody: '{original_title}'")

    # Krok 1: Normalizace vstupního řetězce
    title_for_regex = re.sub(r'[\s\.\+\-_]+', ' ', title).strip()
    log_debug(f"Normalizovaný název pro regex matching: '{title_for_regex}'")

    # Krok 2: Odstranění běžných formátů rozsahů epizod nebo duplicitních informací
    title_for_regex = re.sub(r'(?i)\bS(\d{1,2})E(\d{1,2})[-–]\d{1,2}\b', r'S\1E\2', title_for_regex)
    title_for_regex = re.sub(r'(?i)\b(S\d{1,2}E\d{1,2})\b.*?\b(\d{1,2}[x\-\.]\d{1,2})\b', r'\1', title_for_regex)
    title_for_regex = re.sub(r'(?i)\b(\d{1,2}[x\-\.]\d{1,2})\b.*?\b(S\d{1,2}E\d{1,2})\b', r'\2', title_for_regex)
    log_debug(f"Vyčištěný název pro regex po odstranění rozsahů/duplicit: '{title_for_regex}'")

    # Krok 3: Definování vzorů s prioritou (od nejpřesnějších po obecnější)
    patterns = [
        # 1. Nejpřesnější pro "série" a "díl" (např. "Název 10. série 6. díl")
        r'(?i)(?P<name>.*?)\s+(?P<season>\d{1,2})(?:\s*série|serie)[\s\._-]*?(?:d[ií]l)?\s*(?P<episode>\d{1,2})(?:\s*d[ií]l)?(?P<extra>.*)',
        
        # 2. Alternativní pro "série" a "díl", kdy je díl hned za slovem "díl" (např. "Název série 10 díl 6")
        r'(?i)(?P<name>.*?)(?:série|serie)\s*(?P<season>\d{1,2})[\s\._-]*?(?:d[ií]l)\s*(?P<episode>\d{1,2})(?P<extra>.*)',
        
        # 3. Standardní SxxExx formát (např. "Název S01E05") - Dáme ho sem, je dost specifický
        r'(?i)(?P<name>.*?)\s*S(?P<season>\d{1,2})E(?P<episode>\d{1,2})(?P<extra>.*)',

        # 4. Numerický XxY formát (např. "Název 01x05") - Toto by se mělo chytit na 7x21
        r'(?i)(?P<name>.*?)\s*(?P<season>\d{1,2})x(?P<episode>\d{1,2})(?P<extra>.*)',

        # 5. Formát "Název XX YY" nebo "Název-XX-YY" nebo "Název.XX.YY" (kde XX=sezona, YY=epizoda)
        # Tento pattern by se měl chytit na "06 17" pro Dva a půl chlapa.
        r'(?i)(?P<name>.*?)\s*(?P<season>\d{1,2})[\s\._-](?P<episode>\d{1,2})(?!\d)(?P<extra>.*)',
    ]

    for i, pat in enumerate(patterns):
        match = re.search(pat, title_for_regex)
        if match:
            log_debug(f"Nalezen vzor (index {i}): '{pat}' pro název: '{original_title}'")
            
            log_debug(f"RAW group values for pattern {i}:")
            for group_name in ["name", "season", "episode", "extra"]:
                try:
                    log_debug(f"  {group_name}: '{match.group(group_name)}'")
                except IndexError:
                    log_debug(f"  {group_name}: (Group not found)")
                except KeyError:
                    log_debug(f"  {group_name}: (Named group not present)")

            name = match.group("name")
            season = match.group("season").zfill(2)
            episode = match.group("episode").zfill(2)
            extra = match.groupdict().get("extra", "")

            # --- ZDE ODSTRANÍME DIAKRITIKU Z NÁZVU ---
            name = remove_diacritics(name)
            # --- KONEC ODSTRANĚNÍ DIAKRITIKY ---

            # Krok 4: Dodatečné čištění extrahovaných skupin
            name = re.sub(r'[\.\+\-_]+', ' ', name).strip()
            extra = re.sub(r'[\.\+\-_]+', ' ', extra).strip()
            
            # Další čištění "extra" - odstranění potenciálních zbytků souborových přípon na konci
            extra = re.sub(r'\s*\.(mkv|avi|mp4|srt|sub|cz|en|sk|dub|orig|titulky|dabing|dvdrip|webrip|hd|fhd|sd|x264|x265|h264|h265)\b.*$', '', extra, flags=re.IGNORECASE).strip()
            # Odstranění závorek a jejich obsahu (jako OOR)
            extra = re.sub(r'\s*\(.*?\)\s*', '', extra).strip()
            # Odstranění čísel na konci extra, pokud jsou osamocená (jako ty 17, 15 na screenshotu)
            extra = re.sub(r'\s*\b\d{1,3}\b$', '', extra).strip()

            log_debug(f"Extrahováno (po finálním čištění): Název='{name}', Sezóna='{season}', Epizoda='{episode}', Extra='{extra}'")
            
            return name, season, episode, extra

    # Fallback pro případy, kdy se nenajde žádný vzor sezóny/epizody
    fallback_name = re.sub(r'[\s\.\+\-_]+', ' ', original_title).strip()
    # --- ZDE ODSTRANÍME DIAKRITIKU I Z FALLBACK NÁZVU ---
    fallback_name = remove_diacritics(fallback_name)
    # --- KONEC ODSTRANĚNÍ DIAKRITIKY ---
    log_debug(f"Nenalezen žádný vzor pro název: '{original_title}'. Používám fallback název: '{fallback_name}'")
    return fallback_name, "01", "00", ""

# --- Funkce pro správu cache vyhledávání ---
def load_search_cache(cache_key):
    """Načte výsledky hledání z cache."""
    try:
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
                cache = json.load(f)
                log_debug(f"Načítám cache pro klíč: {cache_key}")
                return cache.get(cache_key)
    except Exception as e:
        log_debug(f"Chyba při načítání cache hledání: {e}")
    return None

def save_search_cache(cache_key, data):
    """Uloží výsledky hledání do cache."""
    try:
        cache_dir = os.path.dirname(search_cache_file)
        if not xbmcvfs.exists(cache_dir):
            xbmcvfs.mkdirs(cache_dir)
        cache = {}
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
                cache = json.load(f)
        cache[cache_key] = data
        # Omezení velikosti cache na posledních 10 hledání
        if len(cache) > 10:
            cache = dict(list(cache.items())[-10:])
        with open(search_cache_file, "w", encoding="utf-8") as f: # ZDE ZAJIŠTĚNO UTF-8
            json.dump(cache, f, ensure_ascii=False, indent=2)
        log_debug(f"Uložena cache pro klíč: {cache_key}")
    except Exception as e:
        log_debug(f"Chyba při ukládání cache hledání: {e}")

def clear_search_cache():
    """Vymaže cache výsledků hledání."""
    try:
        if xbmcvfs.exists(search_cache_file):
            xbmcvfs.delete(search_cache_file)
            log_debug("Cache výsledků hledání vymazána.")
    except Exception as e:
        log_debug(f"Chyba při mazání cache: {e}")

# --- Hlavní navigační a zobrazovací funkce ---
def list_main_menu():
    """Zobrazí hlavní menu pluginu."""
    url = build_url({'mode': 'search'})
    li = xbmcgui.ListItem(label='Vyhledat')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'history'})
    li = xbmcgui.ListItem(label='Historie hledání')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'watch_history'})
    li = xbmcgui.ListItem(label='Historie sledování')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(addon_handle, updateListing=False, cacheToDisc=False)
    
def list_history():
    """Zobrazí historii hledání v Kodi."""
    history = load_query_history()
    if not history:
        xbmcgui.Dialog().ok("Historie hledání", "Historie hledání je prázdná.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    for item in history:
        if '|' in item:
            query, count = item.split('|', 1)
        else:
            query, count = item, '?' # Fallback pro starší formáty
        search_url = build_url({'mode': 'repeat_search', 'query': query})
        remove_url = build_url({'mode': 'delete_history_item', 'query': query})
        li = xbmcgui.ListItem(label=f"{query} ({count})")
        li.addContextMenuItems([("Smazat z historie", f"RunPlugin({remove_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_search_results(query, page=1):
    """
    Získává výsledky hledání z Hellspy.to, zpracuje je a zobrazí.
    Využívá cache pro již prohledané dotazy.
    """
    log_debug(f"Spouštím list_search_results pro dotaz: '{query}', stránka: {page}")

    cache_key = hashlib.md5(query.encode('utf-8')).hexdigest()
    cached_data = load_search_cache(cache_key)

    processed_items = []
    total_items = 0

    # Nejprve zkusíme načíst data z cache, bez ohledu na číslo stránky.
    # Cache by měla vždy obsahovat VŠECHNY nalezené výsledky pro daný dotaz.
    if cached_data:
        processed_items = cached_data
        total_items = len(processed_items)
        log_debug(f"Používám cached výsledky pro '{query}'. Celkem: {total_items} položek.")
        # Pokud jsme našli data v cache, přeskočíme stahování z Hellspy.
    else:
        # Pokud data v cache nejsou, pak je stáhneme z Hellspy.to
        all_items_from_hellspy = []
        
        progress = xbmcgui.DialogProgress()
        progress.create("Hledání na Hellspy", f"Načítám výsledky pro: {query}")

        try:
            log_debug(f"Načítám výsledky z Hellspy.to pro dotaz: '{query}'")
            progress.update(0, "Načítám výsledky z Hellspy.to...")
            
            hellspy_search_url = f"{base_url}/?query={urllib.parse.quote(query)}&page=1"
            
            try:
                html = get_html(hellspy_search_url)
                soup = BeautifulSoup(html, "html.parser")
                items = soup.select('.result-video')

                if items:
                    all_items_from_hellspy.extend(items)
                else:
                    log_debug(f"Nenalezeny žádné video položky na Hellspy.to pro dotaz: {query}")

                progress.update(100, "Načítání dokončeno.")
                xbmc.sleep(300)
            except Exception as e:
                log_debug(f"Chyba při načítání výsledků z Hellspy.to: {e}")
                xbmcgui.Dialog().ok("Chyba", f"Nepodařilo se načíst výsledky z Hellspy.to pro '{query}'.")
                
        finally:
            progress.close()

        if progress.iscanceled():
            xbmc.executebuiltin("Container.Refresh")
            return

        if not all_items_from_hellspy:
            xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyl nalezen žádný výsledek.")
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
            return

        seen_original_titles = set() # NOVÝ SET PRO DEDUPLIKACI PODLE NÁZVU
        processed_items = []
        for item in all_items_from_hellspy:
            try:
                title = item["title"].strip() # Původní název z Hellspy.to

                # --- NOVÁ LOGIKA DEDUPLIKACE PODLE NÁZVU ---
                if title in seen_original_titles:
                    log_debug(f"Duplicitní název '{title}' nalezen, přeskočeno.")
                    continue
                seen_original_titles.add(title)
                # --- KONEC NOVÉ LOGIKY ---

                href = item["href"]
                video_id_match = re.search(r'/video/(\d+/\d+)', href)
                video_id = video_id_match.group(1) if video_id_match else hashlib.md5(href.encode('utf-8')).hexdigest()

                # Ponecháme i deduplikaci podle video_id, pro jistotu, ale primární je teď název
                # Někdy se můžou lišit jen ID, ale název je stejný (pokud Hellspy vrací duplicity s jiným ID)
                # Pokud byste chtěl deduplikovat POUZE podle názvu a ID ignorovat, můžete tento blok s seen_ids odstranit.
                # Prozatím ho ponecháme jako sekundární kontrolu.
                # if video_id in seen_ids:
                #     log_debug(f"Duplicitní video_id '{video_id}' pro '{title}', přeskočeno.")
                #     continue
                # seen_ids.add(video_id)
                # POZN: Pokud odstraníte výše uvedené, nezapomeňte smazat i "seen_ids = set()" nad cyklem.
                # Pro váš požadavek je teď hlavní seen_original_titles.

                video_page_url = urllib.parse.urljoin(base_url, href)
                img_tag = item.find("img")
                thumbnail = img_tag["src"] if img_tag else ""

                name, season, episode, extra = extract_episode_info(title)

                processed_items.append({
                    'original_name': name,
                    'season': int(season),
                    'episode': int(episode),
                    'extra': extra,
                    'video_page_url': video_page_url,
                    'thumbnail': thumbnail,
                    'original_title': title, # Původní název pro zobrazení
                    'id': video_id
                })
            except Exception as e:
                log_debug(f"Chyba při zpracování položky Hellspy: {e}")
                continue

        # Seřazení podle názvu, sezóny a epizody
        processed_items.sort(key=lambda x: (
            x['original_name'].lower(),
            x['season'],
            x['episode']
        ))
        total_items = len(processed_items)
        save_search_cache(cache_key, processed_items)

    # --- Zobrazení stránek v Kodi (zpracovává již načtené a seřazené výsledky) ---
    total_pages = max(1, (total_items + results_per_page - 1) // results_per_page)
    start_idx = (page - 1) * results_per_page
    end_idx = start_idx + results_per_page
    page_items = processed_items[start_idx:end_idx]

    # Přidat "Domů" vždy nahoře
    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR lightblue]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    # Přidání navigace pro předchozí stránku (zobrazení z cache)
    if page > 1:
        prev_url = build_url({
            'mode': 'repeat_search',
            'query': query,
            'page': page - 1
        })
        li_prev = xbmcgui.ListItem(label=f"[B][COLOR yellow]← Předchozí ({page-1}/{total_pages})[/COLOR][/B]")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=prev_url, listitem=li_prev, isFolder=True)

    # Zpracování položek na aktuální stránce
    for item in page_items:
        # Používáme original_name jako základ, TMDb vynechán
        final_name = item['original_name']

        if item['episode'] == 0:
            formatted_title = final_name.strip()
        else:
            formatted_title = f"{final_name} - S{item['season']:02d}E{item['episode']:02d}"

        if item['extra']:
            extra_clean = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
            if extra_clean: # Přidat jen pokud není prázdné po čištění
                formatted_title += f" - {extra_clean}"

        li = xbmcgui.ListItem(label=formatted_title)
        li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        li.setInfo("video", {
            "title": formatted_title,
            "tvshowtitle": final_name, # Použijeme original_name jako tvshowtitle
            "season": item['season'],
            "episode": item['episode']
        })
        li.setProperty("IsPlayable", "true")

        play_url = build_url({'mode': 'play', 'url': item['video_page_url']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)

    # Přidání navigace pro další stránku
    if page < total_pages:
        next_url = build_url({
            'mode': 'repeat_search',
            'query': query,
            'page': page + 1
        })
        li_next = xbmcgui.ListItem(label=f"[B][COLOR yellow]Další → ({page+1}/{total_pages})[/COLOR][/B]")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=li_next, isFolder=True)

    save_query_to_history(query, total_items) # Uložíme celkový počet nalezených (unikátních) položek
    # Použít cacheToDisc=True pro výsledky vyhledávání
    # To řekne Kodi, aby si tento adresář uložilo do cache a při návratu z přehrávání ho načetlo z cache,
    # aniž by volalo skript znovu.
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeno {len(page_items)} položek na stránce {page}/{total_pages} (z celkem {total_items} nalezených).")


def play_video(url):
    """
    Přehrává video z dané URL stránky.
    Extrahování přímého odkazu na video ze stránky Hellspy.
    """
    log_debug(f"Pokouším se přehrát video z URL: {url}")
    try:
        html = get_html(url)
    except Exception:
        # get_html již zobrazí chybovou zprávu
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    video_url = None
    title = "Neznámý název"

    # Hledání 'self.__next_f.push([1,"..."])' pro extrakci JSON bloku
    matches = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html)
    log_debug(f"Nalezeno {len(matches)} potenciálních JSON bloků pro video URL.")

    for i, raw_string in enumerate(matches):
        try:
            # Dekódování unicode_escape je klíčové
            decoded_str = bytes(raw_string, "utf-8").decode("unicode_escape")
            log_debug(f"Zpracovávám blok {i+1}: Dekódovaný string začíná: {decoded_str[:100]}...")

            # Hledání klíče "initialVideo" a extrakce JSON objektu
            match = re.search(r'"initialVideo"\s*:\s*(\{.*?\})\s*,\s*"initialVideoId"', decoded_str, re.DOTALL)
            if not match:
                log_debug(f"Blok {i+1}: Regex pro 'initialVideo' se nezdařil.")
                continue

            video_json_str = match.group(1)
            log_debug(f"Blok {i+1}: Extrahována část JSONu pro 'initialVideo': {video_json_str[:200]}...")

            video_json = json.loads(video_json_str)
            log_debug(f"Blok {i+1}: JSON úspěšně parsován.")

            # Priorita kvality pro výběr video URL
            conversions = video_json.get("conversions", {})
            log_debug(f"Dostupné konverze: {list(conversions.keys())}")

            quality_order = ["1080", "720", "480", "360", "240"]
            for quality in quality_order:
                if quality in conversions and conversions[quality]:
                    video_url = conversions[quality]
                    log_debug(f"Vybrána kvalita {quality}: {video_url}")
                    break

            # Fallback na jakoukoliv dostupnou konverzi, pokud nebyla nalezena preferovaná kvalita
            if not video_url:
                for key, value in conversions.items():
                    if value:
                        video_url = value
                        log_debug(f"Fallback: Použita kvalita '{key}': {video_url}")
                        break

            # Další fallback - hledání v alternativních klíčích
            if not video_url:
                alt_keys = ["url", "src", "source", "file", "mp4"]
                for key in alt_keys:
                    if key in video_json and video_json[key]:
                        video_url = video_json[key]
                        log_debug(f"Fallback: Nalezen alternativní klíč '{key}': {video_url}")
                        break

            if not video_url:
                log_debug(f"Blok {i+1}: V 'initialVideo' JSONu nebyla nalezena žádná platná video URL.")
                log_debug(f"Celý JSON 'initialVideo': {json.dumps(video_json, indent=2)}")
                continue

            # Validace, že URL je platná HTTP/HTTPS
            if not video_url.startswith(('http://', 'https://')):
                log_debug(f"Blok {i+1}: Nalezená URL není platná HTTP/HTTPS adresa: {video_url}")
                continue

            # Získání titulku pro historii sledování
            title = video_json.get("title", "Neznámý název videa")
            log_debug(f"Původní název z JSONu pro historii: '{title}'")

            # Pokus o vyčištění a normalizaci názvu
            # Toto se snaží opravit případné Mojibake, pokud je název již špatně dekódován
            try:
                # Nejběžnější případ Mojibake (UTF-8 dekódované jako Latin-1)
                corrected_title = title.encode('latin1').decode('utf-8')
                log_debug(f"Pokus o Latin-1 -> UTF-8 korekci: '{corrected_title}'")
                # Zkontrolujeme, zda korekce vedla k vizuálně správnějšímu textu a neobsahuje Â
                # (Znak Â je častý indikátor Mojibake)
                if 'Â' in title and 'Â' not in corrected_title: # Jednoduchá heuristika
                    title = corrected_title
                    log_debug(f"Název opraven na: '{title}'")
                elif 'Ã' in title and 'Ã' not in corrected_title: # Další indikátor Mojibake
                     title = corrected_title
                     log_debug(f"Název opraven na: '{title}'")
                # Pokud by se název po korekci zhoršil nebo zůstal stejný, použijeme původní
                # Lze přidat další heuristiky, např. kontrolu na existenci "podivných" znaků
            except (UnicodeEncodeError, UnicodeDecodeError) as e:
                log_debug(f"Chyba při pokusu o korekci kódování názvu '{title}': {e}")
                # Pokud dojde k chybě, použijeme původní název
            except Exception as e:
                log_debug(f"Neočekávaná chyba při korekci kódování názvu: {e}")

            log_debug(f"Finální název pro historii: '{title}'")
            break # Nalezeno a zpracováno první video, ukončíme hledání

        except json.JSONDecodeError as e:
            log_debug(f"Blok {i+1}: Chyba při parsování JSONu: {e}")
            continue
        except Exception as e:
            log_debug(f"Blok {i+1}: Obecná chyba při zpracování bloku: {e}")
            continue

    if not video_url:
        log_debug("Nepodařilo se najít žádnou streamovací URL po prohledání všech bloků.")
        # Fallback: Zkusit najít <video> tag přímo v HTML, i když to Hellspy obvykle nepoužívá
        soup = BeautifulSoup(html, "html.parser")
        video_tags = soup.find_all("video")
        if video_tags:
            for video in video_tags:
                src = video.get("src") or (video.find("source") and video.find("source").get("src"))
                if src and src.startswith(('http://', 'https://')):
                    video_url = src
                    title = "Video z HTML tagu"
                    log_debug(f"Nalezen video tag s src: {src}")
                    break
        
    if video_url:
        save_watch_history_entry(url, title)

        # Pokus o detekci MIME typu pro lepší kompatibilitu
        mime_type = "video/mp4" # Základní default
        if video_url.endswith('.m3u8'):
            mime_type = "application/vnd.apple.mpegurl" # HLS stream
        elif video_url.endswith('.webm'):
            mime_type = "video/webm"
        elif video_url.endswith('.avi'):
            mime_type = "video/x-msvideo"
        
        listitem = xbmcgui.ListItem(path=video_url)
        listitem.setMimeType(mime_type)
        listitem.setProperty("IsPlayable", "true")
        listitem.setContentLookup(False) # Důležité pro přímé přehrávání

        # Přidání User-Agent hlavičky, pokud je potřeba pro streamování z Hellspy
        if not ("User-Agent=" in video_url) and base_url in video_url:
             # Doporučuji použít User-Agent prohlížeče, Hellspy to může vyžadovat.
            video_url += "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
            listitem.setPath(video_url) # Aktualizovat cestu s hlavičkou
            
        xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
        log_debug(f"Streamování videa: {video_url}")
    else:
        xbmcgui.Dialog().ok("Chyba přehrávání", "Nepodařilo se získat přímý odkaz na video.\nZkontrolujte logy pro více informací.")
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

# --- Router pro zpracování volání pluginu ---
def router(paramstring):
    """Router pro zpracování různých módů pluginu."""
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')

    if mode == 'search':
        xbmcplugin.endOfDirectory(addon_handle, updateListing=False) # Ukončí aktuální adresář před zobrazením klávesnice
        keyboard = xbmcgui.Dialog().input("Zadejte hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
        if keyboard:
            # Aktualizuje kontejner, aby zobrazil výsledky hledání
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'repeat_search', 'query': keyboard, 'page': 1})})")
        else:
            # Pokud uživatel zruší, vrátí se do hlavního menu nebo obnoví předchozí zobrazení
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
    elif mode == 'repeat_search':
        page = int(params.get('page', 1))
        query = params['query']
        list_search_results(query, page)
    elif mode == 'delete_history_item':
        delete_query_from_history(params['query'])
        xbmc.executebuiltin(f"Container.Refresh") # Obnoví zobrazení historie
    elif mode == 'history':
        list_history()
    elif mode == 'watch_history':
        list_watch_history()
    elif mode == 'play':
        play_video(params['url'])
    elif mode == 'main':
        clear_search_cache() # Vymaže cache při návratu do hlavního menu
        list_main_menu()
    else:
        list_main_menu()

# --- Spuštění routeru ---
if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')