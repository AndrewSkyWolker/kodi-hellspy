import sys
import os
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import re
import unicodedata
import hashlib
from collections import defaultdict

# Dynamický import knihoven ze složky resources/lib
lib_dir = xbmcvfs.translatePath("special://home/addons/plugin.video.hellspy/resources/lib")
sys.path.insert(0, lib_dir)

# IMPORTY po nastavení sys.path
import cloudscraper
from bs4 import BeautifulSoup
import requests

# === Načtení konfigurace z nastavení doplňku ===
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])

base_url = 'https://www.hellspy.to'
results_per_page = int(addon.getSetting('results_per_page') or 64)
search_history_limit = int(addon.getSetting('search_history_limit') or 10)
watch_history_limit = int(addon.getSetting('watch_history_limit') or 20)
#TMDB_API_KEY = addon.getSetting('tmdb_api_key') or ""
tmdb_api_key_input = addon.getSetting('tmdb_api_key')

# === Bezpečné uložení API klíče do souboru ===
key_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_api.key")

if tmdb_api_key_input and tmdb_api_key_input != "API klíč vložen":
    with open(key_file, "w", encoding="utf-8") as f:
        f.write(tmdb_api_key_input.strip())
    addon.setSetting("tmdb_api_key", "API klíč vložen")

# === Načtení API klíče ze souboru ===
if xbmcvfs.exists(key_file):
    with open(key_file, "r", encoding="utf-8") as f:
        TMDB_API_KEY = f.read().strip()
else:
    TMDB_API_KEY = ""

# === Cesty k souborům ===
history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/history.txt")
watch_history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history.txt")
cached_results_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/cache.json")
search_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/search_cache.json")

def tmdb_search_title(query):
    try:
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_API_KEY}&language=cs-CZ&query={urllib.parse.quote(query)}"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        if data.get("results"):
            for item in data["results"]:
                name = item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title")
                if name:
                    return name  # Vrátí první odpovídající výsledek
    except Exception as e:
        log_debug(f"TMDb API chyba: {e}")
    return None

def log_debug(message):
    xbmc.log(f"[Hellspy DEBUG] {message}", xbmc.LOGINFO)

def save_query_to_history(query, results_count):
    try:
        history_dir = os.path.dirname(history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        history = load_query_history()
        entry = f"{query}|{results_count}"
        history = [h for h in history if not h.startswith(f"{query}|")]
        history.insert(0, entry)
        history = history[:search_history_limit]
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
    except Exception as e:
        log_debug(f"Chyba při zápisu do historie: {e}")

def load_query_history():
    try:
        with open(history_file, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except Exception:
        return []

def delete_query_from_history(query):
    try:
        history = load_query_history()
        history = [h for h in history if not h.startswith(f"{query}|")]
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
    except Exception as e:
        log_debug(f"Chyba při mazání z historie: {e}")

# -- HISTORIE SLEDOVÁNÍ --
watch_history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history.txt")

def save_watch_history_entry(video_page_url, title):
    try:
        parsed = urllib.parse.urlparse(video_page_url)
        parts = parsed.path.split('/')
        if len(parts) >= 4 and parts[1] == "video":
            video_id = f"{parts[2]}/{parts[3]}"
        else:
            log_debug(f"Chybný formát URL: {video_page_url}")
            return
        history_dir = os.path.dirname(watch_history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        existing = []
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                existing = [line.strip() for line in f if line.strip()]
        entry = f"{video_id}|{title}"
        existing = [e for e in existing if not e.startswith(video_id)]
        existing.insert(0, entry)
        existing = existing[:watch_history_limit]
        with open(watch_history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(existing))
    except Exception as e:
        log_debug(f"Chyba při ukládání historie sledování: {e}")

def load_watch_history_list():
    try:
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                return [line.strip().split('|', 1) for line in f if '|' in line]
    except Exception as e:
        log_debug(f"Chyba při načítání historie sledování: {e}")
    return []

def list_watch_history():
    history = load_watch_history_list()
    for video_id, title in history:
        play_url = build_url({'mode': 'play', 'url': f"{base_url}/video/{video_id}"})
        li = xbmcgui.ListItem(label=title)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def strong_normalize(name):
    normalized = name.lower()
    normalized = re.sub(r'[\W_]+', ' ', normalized)  # Nahradí vše kromě písmen a čísel mezerou
    normalized = re.sub(r'\s+', ' ', normalized).strip()
    return normalized

def extract_episode_info(title):
    # Odstraň rozsahy a duplicity epizod jako "S01E15-32", "01x03 S01E03", atd.
    title = re.sub(r'(?i)\bS(\d{1,2})E(\d{1,2})[-–]\d{1,2}\b', r'S\1E\2', title)
    title = re.sub(r'\b(S\d{1,2}E\d{1,2})\b.*?\b(\d{1,2}[x\-\.]\d{1,2})\b', r'\1', title, flags=re.IGNORECASE)
    title = re.sub(r'\b(\d{1,2}[x\-\.]\d{1,2})\b.*?\b(S\d{1,2}E\d{1,2})\b', r'\2', title, flags=re.IGNORECASE)

    patterns = [
        
        # SxxExx nebo sxxexx
        r'(?i)(?P<name>.*?)[\s\-_.]*S(?P<season>\d{1,2})E(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01x05 nebo 1x5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})x(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01.05 nebo 1.5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\.(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01-05 nebo 1-5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})-(?P<episode>\d{1,2})(?P<extra>.*)',

        # 10. série 5. díl
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\.\s*(?:serie|série)[\s\-_.]*(?P<episode>\d{1,2})\.?\s*(?:d[ií]l)?(?P<extra>.*)',

        # série 1 díl 2
        r'(?i)(?P<name>.*?)(?:série|serie)[\s\-_.]*(?P<season>\d{1,2})[\s\-_.]*d[ií]l[\s\-_.]*(?P<episode>\d{1,2})(?P<extra>.*)',

        # 10 série 5 díl
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\s*(?:série|serie)[\s\-_.]*(?P<episode>\d{1,2})\s*d[ií]l(?P<extra>.*)',
        
        # nový vzor pro 03.-05, 03.05, 03 - 05 apod., ale pouze pokud není následován rokem (kvůli filmům)
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})[\.\-\s]+(?P<episode>\d{1,2})(?!\d)(?P<extra>.*)',

        # fallback bez sezóny a epizody
        r'(?i)(?P<name>.*?)(?P<extra>.*)'
    ]
    # Pokud je přítomný platný formát SxxExx nebo 01x05, zpracuj jej i přes rok
    for pat in patterns[:-1]:  # vynecháme fallback
        match = re.match(pat, title)
        if match:
            name = match.group("name").strip(" -_.")
            season = match.groupdict().get("season", "01").zfill(2)
            episode = match.groupdict().get("episode", "00").zfill(2)
            extra = match.groupdict().get("extra", "").strip(" -_.")
            return name, season, episode, extra

    # Jinak, pokud je pravděpodobně film (rok), vrať bez epizody
    if re.search(r'\b(19\d{2}|20[0-4]\d|2050)\b', title):
        return title.strip(), "01", "00", ""

    # fallback (něco úplně jiného)
    match = re.match(patterns[-1], title)
    if match:
        name = match.group("name").strip(" -_.")
        extra = match.groupdict().get("extra", "").strip(" -_.")
        return name, "01", "00", extra

    for pat in patterns:
        match = re.match(pat, title)
        if match:
            name = match.group("name").strip(" -_.")
            season = match.groupdict().get("season", "01").zfill(2)
            episode = match.groupdict().get("episode", "00").zfill(2)
            extra = match.groupdict().get("extra", "").strip(" -_.")
            return name, season, episode, extra
    return title.strip(), "01", "00", ""

def list_main_menu():
    url = build_url({'mode': 'search'})
    li = xbmcgui.ListItem(label='Vyhledat')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    url = build_url({'mode': 'history'})
    li = xbmcgui.ListItem(label='Historie hledání')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    url = build_url({'mode': 'watch_history'})
    li = xbmcgui.ListItem(label='Historie sledování')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(addon_handle, updateListing=False, cacheToDisc=False)

def list_history():
    history = load_query_history()
    for item in history:
        if '|' in item:
            query, count = item.split('|', 1)
        else:
            query, count = item, '?'  # fallback
        search_url = build_url({'mode': 'repeat_search', 'query': query})
        remove_url = build_url({'mode': 'delete_history_item', 'query': query})
        li = xbmcgui.ListItem(label=f"{query} ({count})")
        li.addContextMenuItems([("Smazat z historie", f"RunPlugin({remove_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def get_html(url):
    scraper = cloudscraper.create_scraper()
    try:
        response = scraper.get(url, timeout=10)
        log_debug(f"GET {url} → Status {response.status_code}")
        return response.text
    except Exception as e:
        log_debug(f"Chyba při spojení: {e}")
        xbmcgui.Dialog().ok("Chyba připojení", "Nepodařilo se spojit se serverem Hellspy.\nZkuste to znovu.")
        raise

def list_search_results(query, page=1):
    # Načtení cache nebo nové načítání
    cache_key = hashlib.md5(query.encode('utf-8')).hexdigest()
    cached_data = load_search_cache(cache_key)
    
    if cached_data and page == 1:
        processed_items = cached_data
        log_debug("Používám cached výsledky")
    else:
        # Načtení všech výsledků pouze při prvním volání nebo při obnovení
        all_items = []
        current_page = 1
        has_more = True
        max_pages = 10  # Maximální počet stránek k načtení
        
        progress = xbmcgui.DialogProgress()
        progress.create("Hledání", f"Načítám výsledky pro: {query}")
        
        try:
            while has_more and not progress.iscanceled() and current_page <= max_pages:
                progress.update(int((current_page/max_pages)*100), 
                              f"Načítám stránku {current_page}/{max_pages}")
                
                try:
                    search_url = f"{base_url}/?query={urllib.parse.quote(query)}&page={current_page}"
                    html = get_html(search_url)
                    soup = BeautifulSoup(html, "html.parser")
                    items = soup.select('.result-video')
                    
                    if not items:
                        has_more = False
                        break
                        
                    all_items.extend(items)
                    current_page += 1
                    xbmc.sleep(300)  # Krátká pauza mezi požadavky
                    
                except Exception as e:
                    log_debug(f"Chyba při načítání stránky {current_page}: {e}")
                    has_more = False
                    
        finally:
            progress.close()
        
        if progress.iscanceled():
            xbmc.executebuiltin("Container.Refresh")
            return
        
        if not all_items:
            xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyl nalezen žádný výsledek.")
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
            return

        # Zpracování a seřazení výsledků
        processed_items = []
        seen_ids = set()  # Pro odstranění duplicit
        
        for item in all_items:
            try:
                # Vytvoření unikátního ID pro každé video
                video_id = item["href"].split('/')[-1]
                if video_id in seen_ids:
                    continue
                seen_ids.add(video_id)
                
                title = item["title"].strip()
                href = item["href"]
                video_page_url = urllib.parse.urljoin(base_url, href)
                img_tag = item.find("img")
                thumbnail = img_tag["src"] if img_tag else ""
                
                name, season, episode, extra = extract_episode_info(title)
                name = re.sub(r'[\.\+\-_]+', ' ', name).strip()
                name = re.sub(r'\s+', ' ', name).strip()
                
                if not name:
                    name = title.split()[0] if title.split() else "Neznámý"
                    
                processed_items.append({
                    'original_name': name,
                    'season': int(season),
                    'episode': int(episode),
                    'extra': extra,
                    'video_page_url': video_page_url,
                    'thumbnail': thumbnail,
                    'original_title': title,
                    'id': video_id
                })
            except Exception as e:
                log_debug(f"Chyba při zpracování položky: {e}")
                continue

        # Seřazení podle názvu, sezóny a epizody
        processed_items.sort(key=lambda x: (
            x['original_name'].lower(),
            x['season'],
            x['episode']
        ))
        
        # Uložení do cache
        save_search_cache(cache_key, processed_items)
    
    # Rozdělení na stránky
    total_items = len(processed_items)
    total_pages = max(1, (total_items + results_per_page - 1) // results_per_page)
    start_idx = (page - 1) * results_per_page
    end_idx = start_idx + results_per_page
    page_items = processed_items[start_idx:end_idx]

    # TMDb vyhledávání pro aktuální stránku
    tmdb_cache = {}
    seen_titles = set()
    
    # Zpracování položek na aktuální stránce
    for item in page_items:
        normalized_key = strong_normalize(item['original_name'])
        final_name = tmdb_cache.get(normalized_key, item['original_name'])
        
        # Formátování názvu
        if item['episode'] == 0:
            formatted_title = final_name.strip()
        else:
            formatted_title = f"{final_name} - S{item['season']:02d}E{item['episode']:02d}"
        
        if item['extra']:
            extra = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
            formatted_title += f" - {extra}"

        # Vytvoření položky
        li = xbmcgui.ListItem(label=formatted_title)
        li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        li.setInfo("video", {
            "title": formatted_title,
            "tvshowtitle": final_name,
            "season": item['season'],
            "episode": item['episode']
        })
        li.setProperty("IsPlayable", "true")
        play_url = build_url({'mode': 'play', 'url': item['video_page_url']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)

    # Přidání navigace
    if total_pages > 1:
        # Předchozí stránka
        if page > 1:
            prev_url = build_url({
                'mode': 'repeat_search',
                'query': query,
                'page': page - 1
            })
            li = xbmcgui.ListItem(label=f"[B][COLOR yellow]← Předchozí ({page-1}/{total_pages})[/COLOR][/B]")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=prev_url, listitem=li, isFolder=True)
        
        # Následující stránka
        if page < total_pages:
            next_url = build_url({
                'mode': 'repeat_search',
                'query': query,
                'page': page + 1
            })
            li = xbmcgui.ListItem(label=f"[B][COLOR yellow]Další → ({page+1}/{total_pages})[/COLOR][/B]")
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_url, listitem=li, isFolder=True)

    save_query_to_history(query, total_items)
    xbmcplugin.endOfDirectory(addon_handle)
    log_debug(f"Zobrazeno {len(page_items)} položek (z {total_items} nalezených)")  # Opravený řádek

def load_search_cache(cache_key):
    """Načte výsledky hledání z cache"""
    try:
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f:
                cache = json.load(f)
                return cache.get(cache_key)
    except Exception as e:
        log_debug(f"Chyba při načítání cache hledání: {e}")
    return None

def save_search_cache(cache_key, data):
    """Uloží výsledky hledání do cache"""
    try:
        cache_dir = os.path.dirname(search_cache_file)
        if not xbmcvfs.exists(cache_dir):
            xbmcvfs.mkdirs(cache_dir)
        
        cache = {}
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f:
                cache = json.load(f)
        
        cache[cache_key] = data
        
        # Omezení velikosti cache
        if len(cache) > 10:
            # Ponecháme pouze posledních 10 hledání
            cache = dict(list(cache.items())[-10:])
        
        with open(search_cache_file, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log_debug(f"Chyba při ukládání cache hledání: {e}")

def tmdb_search_title(query):
    """Vyhledání názvu v TMDb s lepším porovnáváním podobnosti"""
    if not TMDB_API_KEY:
        log_debug("TMDb API klíč není nastaven")
        return None
        
    try:
        # Očištění query od speciálních znaků pro lepší vyhledávání
        clean_query = re.sub(r'[^\w\s\-]', ' ', query)
        clean_query = re.sub(r'\s+', ' ', clean_query).strip()
        
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_API_KEY}&language=cs-CZ&query={urllib.parse.quote(clean_query)}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get("results"):
            original_normalized = strong_normalize(query)
            
            for item in data["results"]:
                name = item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title")
                if name:
                    # Normalizované porovnání
                    tmdb_normalized = strong_normalize(name)
                    
                    # Pokud jsou názvy v podstatě stejné, vrať None (použij původní)
                    if original_normalized == tmdb_normalized:
                        log_debug(f"TMDb vrátil stejný název: '{query}' ≈ '{name}' - použit původní")
                        return None
                    
                    # Pokud je TMDb název výrazně jiný, vrať ho
                    log_debug(f"TMDb nalezeno jiné: '{query}' → '{name}'")
                    return name
                    
        log_debug(f"TMDb nenalezeno nebo není relevantní: '{query}'")
        return None
        
    except requests.exceptions.Timeout:
        log_debug(f"TMDb API timeout pro: {query}")
        return None
    except requests.exceptions.RequestException as e:
        log_debug(f"TMDb API chyba pro '{query}': {e}")
        return None
    except Exception as e:
        log_debug(f"TMDb neočekávaná chyba pro '{query}': {e}")
        return None

# Pomocná funkce pro lepší porovnávání podobnosti
def titles_are_similar(title1, title2, threshold=0.8):
    """Porovná dva názvy a vrátí True pokud jsou podobné"""
    if not title1 or not title2:
        return False
        
    # Normalizace
    norm1 = strong_normalize(title1)
    norm2 = strong_normalize(title2)
    
    # Přímé porovnání
    if norm1 == norm2:
        return True
    
    # Jednoduché porovnání délky a překrytí
    if len(norm1) == 0 or len(norm2) == 0:
        return False
        
    # Počet společných slov
    words1 = set(norm1.split())
    words2 = set(norm2.split())
    
    if len(words1) == 0 or len(words2) == 0:
        return False
        
    intersection = len(words1.intersection(words2))
    union = len(words1.union(words2))
    
    similarity = intersection / union if union > 0 else 0
    
    return similarity >= threshold

# Alternativní vylepšená verze tmdb_search_title s detekci podobnosti
def tmdb_search_title_advanced(query):
    """TMDb vyhledávání s pokročilou detekcí podobnosti"""
    if not TMDB_API_KEY:
        return None
        
    try:
        clean_query = re.sub(r'[^\w\s\-]', ' ', query)
        clean_query = re.sub(r'\s+', ' ', clean_query).strip()
        
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_API_KEY}&language=cs-CZ&query={urllib.parse.quote(clean_query)}"
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        data = response.json()
        
        if data.get("results"):
            for item in data["results"]:
                name = item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title")
                if name:
                    # Pokud jsou názvy příliš podobné, nepoužívej TMDb
                    if titles_are_similar(query, name, threshold=0.9):
                        log_debug(f"TMDb název příliš podobný původnímu: '{query}' ≈ '{name}'")
                        return None
                    
                    # Pokud je název výrazně jiný a lepší, použij ho
                    log_debug(f"TMDb nalezeno: '{query}' → '{name}'")
                    return name
                    
        return None
        
    except Exception as e:
        log_debug(f"TMDb chyba: {e}")
        return None

# Přidejte tyto funkce pro správu TMDb cache

# Soubor pro dlouhodobou cache TMDb výsledků
tmdb_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_cache.json")

def load_tmdb_cache():
    """Načte TMDb cache ze souboru"""
    try:
        if xbmcvfs.exists(tmdb_cache_file):
            with open(tmdb_cache_file, "r", encoding="utf-8") as f:
                cache = json.load(f)
                log_debug(f"Načtena TMDb cache s {len(cache)} položkami")
                return cache
    except Exception as e:
        log_debug(f"Chyba při načítání TMDb cache: {e}")
    return {}

def save_tmdb_cache(cache):
    """Uloží TMDb cache do souboru"""
    try:
        cache_dir = os.path.dirname(tmdb_cache_file)
        if not xbmcvfs.exists(cache_dir):
            xbmcvfs.mkdirs(cache_dir)
        
        # Omez velikost cache (max 1000 položek)
        if len(cache) > 1000:
            # Ponech pouze posledních 800 položek
            cache = dict(list(cache.items())[-800:])
        
        with open(tmdb_cache_file, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
        log_debug(f"Uložena TMDb cache s {len(cache)} položkami")
    except Exception as e:
        log_debug(f"Chyba při ukládání TMDb cache: {e}")

def clear_tmdb_cache():
    """Vymaže TMDb cache"""
    try:
        if xbmcvfs.exists(tmdb_cache_file):
            xbmcvfs.delete(tmdb_cache_file)
        log_debug("TMDb cache vymazána")
    except Exception as e:
        log_debug(f"Chyba při mazání TMDb cache: {e}")

# Upravená list_search_results s trvalou cache
def list_search_results_with_persistent_cache(query):
    search_url = f"{base_url}/?query={urllib.parse.quote(query)}"
    html = get_html(search_url)
    soup = BeautifulSoup(html, "html.parser")
    items = soup.select('.result-video')
    results_count = len(items)
    
    if results_count == 0:
        xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyl nalezen žádný výsledek.")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
        return

    # Načti existující cache
    tmdb_cache = load_tmdb_cache()
    cache_updated = False
    seen_titles = set()
    
    # Zpracování položek...
    processed_items = []
    for item in items:
        title = item["title"].strip()
        href = item["href"]
        video_page_url = urllib.parse.urljoin(base_url, href)
        img_tag = item.find("img")
        thumbnail = img_tag["src"] if img_tag else ""
        
        name, season, episode, extra = extract_episode_info(title)
        name = re.sub(r'[\.\+\-_]+', ' ', name).strip()
        name = re.sub(r'\s+', ' ', name).strip()
        
        if not name:
            name = title.split()[0] if title.split() else "Neznámý"
            
        processed_items.append({
            'original_name': name,
            'season': season,
            'episode': episode,
            'extra': extra,
            'video_page_url': video_page_url,
            'thumbnail': thumbnail,
            'original_title': title
        })

    # Seskupení a TMDb vyhledávání
    name_groups = defaultdict(list)
    for item in processed_items:
        normalized_key = strong_normalize(item['original_name'])
        name_groups[normalized_key].append(item)

    # Progress dialog jen pro nové vyhledávání
    new_searches_needed = [key for key in name_groups.keys() if key not in tmdb_cache]
    
    if new_searches_needed and TMDB_API_KEY:
        progress_dialog = xbmcgui.DialogProgress()
        progress_dialog.create("Načítání", "Získávání nových informací z TMDb...")
        
        for i, normalized_name in enumerate(new_searches_needed):
            if progress_dialog.iscanceled():
                progress_dialog.close()
                break
                
            progress_percent = int((i / len(new_searches_needed)) * 100)
            representative_name = name_groups[normalized_name][0]['original_name']
            progress_dialog.update(progress_percent, f"Vyhledávám: {representative_name}")
            
            tmdb_name = tmdb_search_title(representative_name)
            if tmdb_name:
                tmdb_cache[normalized_name] = tmdb_name
                cache_updated = True
            else:
                tmdb_cache[normalized_name] = representative_name
                cache_updated = True
        
        progress_dialog.close()

    # Uložení cache pokud se změnila
    if cache_updated:
        save_tmdb_cache(tmdb_cache)

    # Sestavení výsledků...
    for item in processed_items:
        normalized_key = strong_normalize(item['original_name'])
        final_name = tmdb_cache.get(normalized_key, item['original_name'])
        
        final_name = final_name.capitalize() if final_name else item['original_name']
        
        if item['season'] == "01" and item['episode'] == "00":
            formatted_title = final_name.strip()
        else:
            formatted_title = f"{final_name} - S{item['season']}-E{item['episode']}"

        formatted_title = re.sub(r'^[\s\-]+', '', formatted_title).strip()

        if formatted_title and formatted_title[0].islower():
            formatted_title = formatted_title[0].upper() + formatted_title[1:]

        if item['extra']:
            extra = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
            formatted_title += f" - {extra}"

        key = f"{final_name.lower()}_s{item['season']}_e{item['episode']}"
        if key in seen_titles:
            continue
        seen_titles.add(key)

        li = xbmcgui.ListItem(label=formatted_title)
        li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        li.setInfo("video", {"title": formatted_title})
        li.setProperty("IsPlayable", "true")
        play_url = build_url({'mode': 'play', 'url': item['video_page_url']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)

    save_query_to_history(query, len(seen_titles))
    xbmcplugin.endOfDirectory(addon_handle)
    log_debug(f"Zobrazeno {len(seen_titles)} položek, TMDb cache: {len(tmdb_cache)} položek")

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode == 'search':
        xbmcplugin.endOfDirectory(addon_handle, updateListing=False)
        keyboard = xbmcgui.Dialog().input("Zadejte hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
        if keyboard:
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'repeat_search', 'query': keyboard})})")
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
    elif mode == 'repeat_search':
        page = int(params.get('page', 1))  # Výchozí stránka je 1
        list_search_results(params['query'], page)
    elif mode == 'delete_history_item':
        delete_query_from_history(params['query'])
        xbmc.executebuiltin(f"Container.Refresh")
    elif mode == 'history':
        list_history()
    elif mode == 'watch_history':
        list_watch_history()
    elif mode == 'play':
        play_video(params['url'])
    else:
        list_main_menu()

def analyze_failed_video(url):
    """Analýza problematického videa - zavolejte manuálně pro debugging"""
    try:
        html = get_html(url)
        
        # Uložení HTML pro manuální prohlédnutí
        debug_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/debug_page.html")
        with open(debug_file, "w", encoding="utf-8") as f:
            f.write(html)
        log_debug(f"HTML uloženo do: {debug_file}")
        
        # Analýza všech možných video odkazů
        matches = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html)
        log_debug(f"Celkem nalezeno bloků: {len(matches)}")
        
        for i, raw_string in enumerate(matches):
            try:
                decoded_str = bytes(raw_string, "utf-8").decode("unicode_escape")
                
                # Hledání všech možných video klíčů
                video_patterns = [
                    r'"(https?://[^"]*\.(?:mp4|avi|mkv|webm|m3u8)[^"]*)"',
                    r'"url"\s*:\s*"([^"]+)"',
                    r'"src"\s*:\s*"([^"]+)"',
                    r'"file"\s*:\s*"([^"]+)"',
                    r'"video"\s*:\s*"([^"]+)"'
                ]
                
                for pattern in video_patterns:
                    urls = re.findall(pattern, decoded_str)
                    if urls:
                        log_debug(f"Blok {i+1}, pattern '{pattern}': {urls}")
                        
            except Exception as e:
                log_debug(f"Chyba při analýze bloku {i+1}: {e}")
                
        # Hledání video tagů
        soup = BeautifulSoup(html, "html.parser")
        video_tags = soup.find_all("video")
        if video_tags:
            for j, video in enumerate(video_tags):
                log_debug(f"Video tag {j+1}: {video.attrs}")
                
        # Hledání iframe
        iframes = soup.find_all("iframe")
        if iframes:
            for j, iframe in enumerate(iframes):
                log_debug(f"Iframe {j+1}: {iframe.get('src', 'bez src')}")
                
    except Exception as e:
        log_debug(f"Chyba při analýze: {e}")

def test_video_url(video_url):
    """Test dostupnosti video URL"""
    try:
        response = requests.head(video_url, timeout=5)
        log_debug(f"URL test {video_url}: Status {response.status_code}")
        log_debug(f"Content-Type: {response.headers.get('content-type', 'N/A')}")
        log_debug(f"Content-Length: {response.headers.get('content-length', 'N/A')}")
        return response.status_code == 200
    except Exception as e:
        log_debug(f"URL test failed: {e}")
        return False

def enhanced_log_debug(message, level="INFO"):
    """Vylepšené logování s časem"""
    import datetime
    timestamp = datetime.datetime.now().strftime("%H:%M:%S")
    xbmc.log(f"[Hellspy {level}] {timestamp} - {message}", xbmc.LOGINFO)

def play_video(url):
    html = get_html(url)
    matches = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html)
    
    log_debug(f"Nalezeno {len(matches)} potenciálních JSON bloků")
    
    for i, raw_string in enumerate(matches):
        try:
            decoded_str = bytes(raw_string, "utf-8").decode("unicode_escape")
            log_debug(f"Blok {i+1}: Hledám initialVideo...")
            
            if '"initialVideo":{' in decoded_str:
                log_debug(f"Blok {i+1}: Nalezen initialVideo")
                
                # Pokus o extrakci JSON
                match = re.search(r'"initialVideo"\s*:\s*(\{.*?\})\s*,\s*"initialVideoId"', decoded_str, re.DOTALL)
                if not match:
                    log_debug(f"Blok {i+1}: Regex pro initialVideo se nezdařil")
                    continue
                
                video_json_str = match.group(1)
                log_debug(f"Blok {i+1}: Extrahovány JSON data: {video_json_str[:200]}...")
                
                video_json = json.loads(video_json_str)
                log_debug(f"Blok {i+1}: JSON úspěšně parsován")
                
                # Debug: Zobraz dostupné konverze
                conversions = video_json.get("conversions", {})
                log_debug(f"Dostupné konverze: {list(conversions.keys())}")
                
                # Pokus o nalezení video URL - více variant
                video_url = None
                
                # Priorita kvality
                quality_order = ["1080", "720", "480", "360", "240"]
                for quality in quality_order:
                    if quality in conversions and conversions[quality]:
                        video_url = conversions[quality]
                        log_debug(f"Nalezena kvalita {quality}: {video_url}")
                        break
                
                # Fallback - jakákoliv dostupná konverze
                if not video_url:
                    for key, value in conversions.items():
                        if value:
                            video_url = value
                            log_debug(f"Fallback kvalita {key}: {video_url}")
                            break
                
                # Pokus o alternativní klíče
                if not video_url:
                    alt_keys = ["url", "src", "source", "file", "mp4"]
                    for key in alt_keys:
                        if key in video_json and video_json[key]:
                            video_url = video_json[key]
                            log_debug(f"Nalezen alternativní klíč {key}: {video_url}")
                            break
                
                if not video_url:
                    log_debug(f"Blok {i+1}: Žádná video URL nebyla nalezena")
                    log_debug(f"Celý video_json: {json.dumps(video_json, indent=2)}")
                    continue
                
                # Validace URL
                if not video_url.startswith(('http://', 'https://')):
                    log_debug(f"Neplatná URL: {video_url}")
                    continue
                
                log_debug(f"Finální streamovací URL: {video_url}")
                
                title = video_json.get("title", "Neznámý název")
                save_watch_history_entry(url, title)
                
                # Pokus o detekci MIME typu
                mime_type = "video/mp4"  # default
                if video_url.endswith('.m3u8'):
                    mime_type = "application/vnd.apple.mpegurl"
                elif video_url.endswith('.webm'):
                    mime_type = "video/webm"
                elif video_url.endswith('.avi'):
                    mime_type = "video/x-msvideo"
                
                listitem = xbmcgui.ListItem(path=video_url)
                listitem.setMimeType(mime_type)
                listitem.setProperty("IsPlayable", "true")
                listitem.setContentLookup(False)
                
                # Přidání headers pokud potřeba
                if "|" not in video_url and base_url in video_url:
                    video_url += "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
                    listitem.setPath(video_url)
                
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
                return
                
        except json.JSONDecodeError as e:
            log_debug(f"Blok {i+1}: JSON chyba: {e}")
            continue
        except Exception as e:
            log_debug(f"Blok {i+1}: Obecná chyba: {e}")
            continue

    log_debug("Nepodařilo se najít validní JSON s initialVideo ve všech blocích")
    
    # Fallback - pokus o nalezení video tagů přímo v HTML
    soup = BeautifulSoup(html, "html.parser")
    video_tags = soup.find_all("video")
    if video_tags:
        for video in video_tags:
            src = video.get("src") or (video.find("source") and video.find("source").get("src"))
            if src:
                log_debug(f"Nalezen video tag se src: {src}")
                listitem = xbmcgui.ListItem(path=src)
                listitem.setProperty("IsPlayable", "true")
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
                return
    
    xbmcgui.Dialog().ok("Chyba", "Nepodařilo se získat data o videu.\nZkontrolujte logy pro více informací.")

router(sys.argv[2][1:] if len(sys.argv) > 2 else '')