import sys
import os
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import re
import hashlib
import unicodedata
from collections import defaultdict

# Dynamický import knihoven ze složky resources/lib
lib_dir = xbmcvfs.translatePath("special://home/addons/plugin.video.hellspy/resources/lib")
sys.path.insert(0, lib_dir)

# IMPORTS po nastavení sys.path
import cloudscraper
import requests
from bs4 import BeautifulSoup

# === Cesty k souborům ===
history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/history.txt")
# Samostatné soubory pro historii sledování filmů a seriálů
WATCH_HISTORY_MOVIES_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history_movies.txt")
WATCH_HISTORY_SERIES_FILE = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history_series.txt")

cached_results_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/cache.json")
search_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/search_cache.json")
tmdb_cache_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_cache.json")
tmdb_api_key_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/tmdb_api.key")

# === TMDb Konfigurace ===
TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_IMAGE_BASE_URL = "https://image.tmdb.org/t/p/w500" # URL pro plakáty a miniatury

# === Načtení konfigurace z nastavení doplňku ===
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
base_url = 'https://www.hellspy.to'
results_per_page = int(addon.getSetting('results_per_page') or 64)
search_history_limit = int(addon.getSetting('search_history_limit') or 10)
watch_history_limit = int(addon.getSetting('watch_history_limit') or 20)

def read_cache(cache_file, key):
    """Načte data z cache souboru pro daný klíč."""
    try:
        if xbmcvfs.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache = json.load(f)
            return cache.get(key)
    except Exception as e:
        log_debug(f"Chyba při čtení cache z {cache_file}: {e}")
    return None

def save_cache(cache_file, key, data):
    """Uloží data do cache souboru pro daný klíč."""
    try:
        cache = {}
        if xbmcvfs.exists(cache_file):
            with open(cache_file, 'r', encoding='utf-8') as f:
                try:
                    cache = json.load(f)
                except json.JSONDecodeError:
                    log_debug(f"Cache soubor {cache_file} je poškozený, vytvářím nový.")
                    cache = {}
        
        cache[key] = data
        
        # Omezení velikosti cache na 500 záznamů (nebo jiná hodnota)
        # Aby cache nerostla do nekonečna
        if len(cache) > 500:
            # Odstraníme nejstarší záznamy (náhodně, nebo podle nějakého řazení, zde náhodně)
            # Lepší by bylo třeba podle posledního přístupu, ale to vyžaduje složitější cache strukturu
            for _ in range(len(cache) - 400): # Ponecháme 400, odstraníme 100 nejstarších/náhodných
                cache.pop(next(iter(cache)))

        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=4)
    except Exception as e:
        log_debug(f"Chyba při ukládání cache do {cache_file}: {e}")

def _write_tmdb_api_key_to_file(api_key):
    """Bezpečně zapíše TMDb API klíč do souboru."""
    try:
        tmdb_api_key_dir = os.path.dirname(tmdb_api_key_file)
        if not xbmcvfs.exists(tmdb_api_key_dir):
            xbmcvfs.mkdirs(tmdb_api_key_dir)
            log_debug(f"Vytvořen adresář pro TMDb API klíč: {tmdb_api_key_dir}")
        with open(tmdb_api_key_file, "w", encoding="utf-8") as f:
            f.write(api_key.strip())
        log_debug(f"TMDb API klíč úspěšně zapsán do souboru: {tmdb_api_key_file}")
    except Exception as e:
        log_debug(f"Chyba při zápisu TMDb API klíče do souboru: {e}")

def _get_tmdb_api_key():
    """
    Načte TMDb API klíč.
    Preferuje načtení ze souboru. Pokud soubor neexistuje nebo je prázdný,
    pokusí se klíč načíst z nastavení doplňku a uloží ho do souboru.
    """
    try:
        # 1. Zkusit načíst z souboru
        if xbmcvfs.exists(tmdb_api_key_file):
            with open(tmdb_api_key_file, "r", encoding="utf-8") as f:
                file_key = f.read().strip()
                if file_key:
                    log_debug("TMDb API klíč úspěšně načten ze souboru.")
                    return file_key
        log_debug(f"TMDb API klíč nebyl nalezen v souboru: {tmdb_api_key_file} nebo je soubor prázdný.")

        # 2. Pokud není v souboru, zkusit načíst z nastavení doplňku
        settings_key = addon.getSetting('tmdb_api_key')
        if settings_key:
            log_debug("TMDb API klíč nalezen v nastavení doplňku. Ukládám do souboru.")
            _write_tmdb_api_key_to_file(settings_key)
            return settings_key
        
        log_debug("TMDb API klíč nebyl nalezen ani v nastavení doplňku.")
    except Exception as e:
        log_debug(f"Chyba při načítání TMDb API klíče: {e}")
    return None

def _get_tmdb_data(endpoint, params):
    """
    Provádí GET požadavek na TMDb API a ukládá/načítá data z cache.
    endpoint: např. '/search/multi'
    params: slovník parametrů pro API dotaz
    """
    tmdb_api_key = _get_tmdb_api_key()
    if not tmdb_api_key:
        xbmcgui.Dialog().ok("Chyba TMDb API", "TMDb API klíč není nastaven.\nPřejděte do nastavení doplňku a zadejte svůj klíč.")
        log_debug("Nelze provést TMDb požadavek: API klíč není k dispozici.")
        return None

    # Vytvoření cache klíče z endpointu a parametrů
    cache_key = hashlib.md5(f"{endpoint}-{json.dumps(params, sort_keys=True)}".encode('utf-8')).hexdigest()
    
    # Zkusit načíst z cache
    cached_data = read_cache(tmdb_cache_file, cache_key)
    if cached_data:
        log_debug(f"Používám TMDb data z cache pro klíč: {cache_key}")
        return cached_data

    params['api_key'] = tmdb_api_key
    params['language'] = 'cs' # Preferujeme češtinu

    full_url = f"{TMDB_BASE_URL}{endpoint}?{urllib.parse.urlencode(params)}"
    
    log_debug(f"TMDb API požadavek: {full_url}")
    try:
        response = requests.get(full_url, timeout=10)
        response.raise_for_status() # Vyvolá HTTPError pro špatné odpovědi (4xx nebo 5xx)
        data = response.json()
        save_cache(tmdb_cache_file, cache_key, data) # Uložit do cache
        log_debug(f"TMDb data uložena do cache pro klíč: {cache_key}")
        return data
    except requests.exceptions.Timeout:
        log_debug("TMDb API požadavek vypršel (timeout).")
        xbmcgui.Dialog().ok("Chyba TMDb", "TMDb API požadavek vypršel (timeout). Zkuste to prosím znovu.")
    except requests.exceptions.RequestException as e:
        log_debug(f"Chyba při TMDb API požadavku: {e}")
        xbmcgui.Dialog().ok("Chyba TMDb", f"Chyba při komunikaci s TMDb API: {e}")
    except json.JSONDecodeError as e:
        log_debug(f"Chyba při dekódování TMDb JSON odpovědi: {e}")
        xbmcgui.Dialog().ok("Chyba TMDb", "Chybná odpověď z TMDb API.")
    return None

def search_tmdb(query_text):
    """
    Vyhledá film nebo seriál na TMDb a vrátí relevantní data.
    Pokusí se najít shodu a vrátí kanonický název a ID.
    Tato funkce je určena pro interní použití (např. extract_episode_info),
    kde se očekává jeden "nejlepší" výsledek.
    """
    log_debug(f"Hledám na TMDb pro dotaz: '{query_text}' (vracím nejlepší shodu)")
    params = {'query': query_text}
    data = _get_tmdb_data('/search/multi', params)

    if not data or 'results' not in data:
        return None

    best_match = None
    for result in data['results']:
        # Preferujeme filmy nebo TV pořady
        if result['media_type'] == 'movie' or result['media_type'] == 'tv':
            title = result.get('title') or result.get('name') or result.get('original_title') or result.get('original_name')
            release_date = result.get('release_date', result.get('first_air_date', ''))
            year = release_date.split('-')[0] if release_date else ''
            
            if not best_match: # Vezmeme první shodu, která je film nebo TV pořad
                best_match = {
                    'type': result['media_type'],
                    'tmdb_id': result['id'],
                    'title': title,
                    'year': year,
                    'poster': result.get('poster_path'),
                    'overview': result.get('overview')
                }
                break # Nalezen nejlepší shoda, ukončíme cyklus
    
    if best_match:
        log_debug(f"Nalezen nejlepší TMDb shoda pro '{query_text}': {best_match['title']} ({best_match['type']})")
    else:
        log_debug(f"Nenalezena žádná vhodná TMDb shoda pro '{query_text}'.")
    
    return best_match

def search_tmdb_filtered_list(query_text, media_type_filter):
    """
    Vyhledá filmy nebo seriály na TMDb pro daný typ média a vrátí seznam relevantních dat.
    media_type_filter: 'movie' nebo 'tv'
    """
    log_debug(f"Hledám na TMDb pro dotaz: '{query_text}' s filtrem: '{media_type_filter}' (vracím seznam)")
    params = {'query': query_text}
    data = _get_tmdb_data('/search/multi', params)

    if not data or 'results' not in data:
        return []

    filtered_results = []
    for result in data['results']:
        if result['media_type'] == media_type_filter:
            item = {
                'type': result['media_type'],
                'tmdb_id': result['id'],
                'poster': result.get('poster_path'), # Oprava: Změněno z 'poster' na 'poster_path'
                'overview': result.get('overview')
            }
            if result['media_type'] == 'movie':
                item['title'] = result.get('title') or result.get('original_title')
                release_date = result.get('release_date', '')
                item['year'] = release_date.split('-')[0] if release_date else ''
            elif result['media_type'] == 'tv':
                item['title'] = result.get('name') or result.get('original_name')
                first_air_date = result.get('first_air_date', '')
                item['year'] = first_air_date.split('-')[0] if first_air_date else ''
            
            if item.get('title'): # Zajistíme, že název existuje
                filtered_results.append(item)
    
    log_debug(f"Nalezeno {len(filtered_results)} TMDb shod pro '{query_text}' s filtrem '{media_type_filter}'.")
    return filtered_results

def log_debug(message):
    """Zjednodušená funkce pro logování ladicích zpráv."""
    xbmc.log(f"[Hellspy DEBUG] {message}", xbmc.LOGINFO)

def save_query_to_history(query, results_count):
    """Uloží hledaný dotaz a počet výsledků do historie."""
    try:
        history_dir = os.path.dirname(history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        history = load_query_history()
        entry = f"{query}|{results_count}" 
        history = [h for h in history if not h.startswith(f"{query}|")]
        
        history.insert(0, entry) # Přidá na začátek
        history = history[:search_history_limit] # Omezí počet záznamů
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
        log_debug(f"Dotaz '{query}' uložen do historie s {results_count} výsledky.")
    except Exception as e:
        log_debug(f"Chyba při zápisu do historie hledání: {e}")

def load_query_history():
    """Načte historii hledání."""
    try:
        if xbmcvfs.exists(history_file):
            with open(history_file, "r", encoding="utf-8") as f:
                return [line.strip() for line in f if line.strip()]
    except Exception as e:
        log_debug(f"Chyba při načítání historie hledání: {e}")
    return []

def delete_query_from_history(query):
    """Smaže konkrétní dotaz z historie hledání."""
    try:
        history = load_query_history()
        history = [h for h in history if not h.startswith(f"{query}|")]
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
        log_debug(f"Dotaz '{query}' smazán z historie hledání.")
    except Exception as e:
        log_debug(f"Chyba při mazání z historie hledání: {e}")

def save_watch_history_entry(video_page_url, title, thumbnail_url=""):
    """
    Uloží záznam o sledovaném videu do historie sledování, rozděleného na filmy a seriály.
    Název a náhled se ukládají pro snadné znovuzobrazení.
    """
    try:
        parsed = urllib.parse.urlparse(video_page_url)
        parts = parsed.path.split('/')
        if len(parts) >= 4 and parts[1] == "video":
            video_id = f"{parts[2]}/{parts[3]}"
        else:
            log_debug(f"Chybný formát URL pro uložení do historie sledování: {video_page_url}")
            return

        is_series = False
        # Jednoduchá kontrola, zda název vypadá jako seriálová epizoda
        if re.search(r'(?i)S\d{1,2}E\d{1,2}', title) or \
           re.search(r'(?i)\b\d{1,2}[xX]\d{1,2}\b', title) or \
           re.search(r'(?i)(?:série|serie)\s*\d{1,2}(?:\s*díl|\s*díly)?\s*\d{1,2}', title):
            is_series = True
        
        # Určení souboru pro historii
        if is_series:
            history_file_path = WATCH_HISTORY_SERIES_FILE
            media_type_str = "series"
        else:
            history_file_path = WATCH_HISTORY_MOVIES_FILE
            media_type_str = "movie"

        log_debug(f"Název pro uložení do historie: '{title}' (Typ: {media_type_str}), Náhled: '{thumbnail_url}'")

        history_dir = os.path.dirname(history_file_path)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)

        existing = []
        if xbmcvfs.exists(history_file_path):
            with open(history_file_path, "r", encoding="utf-8") as f:
                existing = [line.strip() for line in f if line.strip()]

        entry = f"{video_id}|{title}|{thumbnail_url}" 
        existing = [e for e in existing if not e.startswith(f"{video_id}|")] 
        existing.insert(0, entry) # Přidáme na začátek
        existing = existing[:watch_history_limit] # Omezíme počet záznamů

        with open(history_file_path, "w", encoding="utf-8") as f:
            f.write("\n".join(existing))
        log_debug(f"Video '{title}' ({video_id}) uloženo do historie sledování ({media_type_str}).")
    except Exception as e:
        log_debug(f"Chyba při ukládání historie sledování: {e}")

def load_watch_history_list(file_path):
    """
    Načte historii sledování z daného souboru a pokusí se opravit problémy s kódováním.
    Nyní načítá i thumbnail_url a poskytuje fallback.
    """
    history_list = []
    try:
        if xbmcvfs.exists(file_path):
            with open(file_path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    parts = line.split('|', 2)
                    if len(parts) >= 2:
                        video_id = parts[0]
                        title = parts[1]
                        thumbnail = parts[2] if len(parts) == 3 else ""

                        try:
                            corrected_title = title.encode('latin1').decode('utf-8')
                            if ('Å' in title or 'Ã' in title) and ('Å' not in corrected_title and 'Ã' not in corrected_title):
                                title = corrected_title
                        except (UnicodeEncodeError, UnicodeDecodeError):
                            pass
                        
                        title = unicodedata.normalize('NFC', title)
                        history_list.append({'video_id': video_id, 'title': title, 'thumbnail': thumbnail})
                    else:
                        log_debug(f"Nepravidelný záznam v historii sledování: {line}")
    except Exception as e:
        log_debug(f"Chyba při načítání historie sledování z {file_path}: {e}")
    return history_list


def delete_watch_history_item(video_id, media_type):
    """Smaže konkrétní záznam z historie sledování (filmy/seriály)."""
    if media_type == 'movie':
        file_path = WATCH_HISTORY_MOVIES_FILE
    elif media_type == 'series':
        file_path = WATCH_HISTORY_SERIES_FILE
    else:
        log_debug(f"Neznámý typ média pro smazání z historie: {media_type}")
        return
    
    try:
        history = load_watch_history_list(file_path)
        history = [item for item in history if item['video_id'] != video_id] 
        
        with open(file_path, "w", encoding="utf-8") as f:
            f.write("\n".join([f"{item['video_id']}|{item['title']}|{item['thumbnail']}" for item in history]))
        log_debug(f"Záznam '{video_id}' ({media_type}) smazán z historie sledování.")
        xbmc.executebuiltin("Container.Refresh")
    except Exception as e:
        log_debug(f"Chyba při mazání z historie sledování: {e}")

def list_watch_history():
    """Zobrazí menu pro historii sledování (Filmy, Seriály)."""
    url_movies_history = build_url({'mode': 'list_watch_history_movies'})
    li_movies_history = xbmcgui.ListItem(label='Filmy')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_movies_history, listitem=li_movies_history, isFolder=True)

    url_series_history = build_url({'mode': 'list_watch_history_series'})
    li_series_history = xbmcgui.ListItem(label='Seriály')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url_series_history, listitem=li_series_history, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_watch_history_movies():
    """Zobrazí historii sledování filmů."""
    log_debug("Načítám historii sledování filmů.")
    xbmcplugin.setContent(addon_handle, 'movies')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'watch_history'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Historii sledování[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    history = load_watch_history_list(WATCH_HISTORY_MOVIES_FILE)
    if not history:
        xbmcgui.Dialog().notification("Historie sledování filmů", "Historie sledování filmů je prázdná.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    for item in history:
        play_url = build_url({'mode': 'play', 'url': f"{base_url}/video/{item['video_id']}", 'display_title': item['title'], 'thumbnail': item['thumbnail']})
        delete_url = build_url({'mode': 'delete_watch_history_item', 'video_id': item['video_id'], 'media_type': 'movie'})

        li = xbmcgui.ListItem(label=item['title']) 
        li.setProperty("IsPlayable", "true")
        li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        
        li.setProperty('ResumeTime', '0') 
        li.setProperty('TotalTime', '1') 

        li.addContextMenuItems([("Smazat z historie", f"RunPlugin({delete_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    
    xbmcplugin.endOfDirectory(addon_handle)

def list_watch_history_series():
    """Zobrazí historii sledování seriálů, seskupené podle seriálu, s nejnovějšími nahoře."""
    log_debug("Načítám historii sledování seriálů.")
    xbmcplugin.setContent(addon_handle, 'tvshows')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'watch_history'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Historii sledování seriálů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    history = load_watch_history_list(WATCH_HISTORY_SERIES_FILE)
    if not history:
        xbmcgui.Dialog().notification("Historie sledování seriálů", "Historie sledování seriálů je prázdná.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    ordered_series_names = []
    seen_series_names = set()
    series_data = defaultdict(list)

    for item in history:
        title = item['title']
        series_name_match = re.match(r'(.*?)(?:\s*-\s*S\d{1,2}E\d{1,2}|\s*S\d{1,2}E\d{1,2})', title, re.IGNORECASE)
        series_name = series_name_match.group(1).strip() if series_name_match else "Neznámý seriál"
        
        if series_name not in seen_series_names:
            ordered_series_names.append(series_name)
            seen_series_names.add(series_name)
        
        series_data[series_name].append(item)

    for series_name in ordered_series_names:
        series_thumbnail = ""
        if series_data[series_name]:
            first_item_in_series = series_data[series_name][0] 
            series_thumbnail = first_item_in_series.get('thumbnail', "")

        if not series_thumbnail:
            log_debug(f"Thumbnail pro seriál '{series_name}' chybí v historii, zkouším TMDb.")
            tmdb_info = search_tmdb(series_name)
            if tmdb_info and tmdb_info.get('poster'):
                series_thumbnail = f"{TMDB_IMAGE_BASE_URL}{tmdb_info['poster']}"
                log_debug(f"Thumbnail pro seriál '{series_name}' nalezen na TMDb: {series_thumbnail}")
            else:
                log_debug(f"Thumbnail pro seriál '{series_name}' nenalezen ani na TMDb.")

        li = xbmcgui.ListItem(label=f"[B][COLOR orange]{series_name}[/COLOR][/B]")
        li.setArt({"thumb": series_thumbnail, "icon": series_thumbnail, "poster": series_thumbnail})
        li.setInfo("video", {"title": series_name, "tvshowtitle": series_name})

        series_folder_url = build_url({'mode': 'list_watch_history_series_episodes', 'series_name': series_name})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_folder_url, listitem=li, isFolder=True)
            
    xbmcplugin.endOfDirectory(addon_handle)

def list_watch_history_series_episodes(series_name):
    """Zobrazí epizody pro konkrétní seriál z historie sledování seriálů, s nejnovějšími díly nahoře."""
    log_debug(f"Načítám historii sledování epizod pro seriál: '{series_name}'.")
    xbmcplugin.setContent(addon_handle, 'episodes')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_watch_history_series'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Historii sledování seriálů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    history = load_watch_history_list(WATCH_HISTORY_SERIES_FILE)
    
    series_episodes = []
    for item in history:
        series_name_match = re.match(r'(.*?)(?:\s*-\s*S\d{1,2}E\d{1,2}|\s*S\d{1,2}E\d{1,2})', item['title'], re.IGNORECASE)
        current_series_name = series_name_match.group(1).strip() if series_name_match else "Neznámý seriál"
        if current_series_name == series_name:
            series_episodes.append(item)

    if not series_episodes:
        xbmcgui.Dialog().notification(f"Historie '{series_name}'", "Pro tento seriál nebyly nalezeny žádné sledované epizody.")
        xbmcplugin.endOfDirectory(addon_handle)
        return
    
    for item in series_episodes:
        play_url = build_url({'mode': 'play', 'url': f"{base_url}/video/{item['video_id']}", 'display_title': item['title'], 'thumbnail': item['thumbnail']})
        delete_url = build_url({'mode': 'delete_watch_history_item', 'video_id': item['video_id'], 'media_type': 'series'})

        li_episode = xbmcgui.ListItem(label=item['title'])
        li_episode.setProperty("IsPlayable", "true")
        li_episode.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        
        episode_match = re.search(r'(?i)S(\d{1,2})E(\d{1,2})', item['title'])
        if episode_match:
            li_episode.setInfo('video', {
                'title': item['title'],
                'tvshowtitle': series_name,
                'season': int(episode_match.group(1)),
                'episode': int(episode_match.group(2)),
                'mediatype': 'episode'
            })
        else:
            li_episode.setInfo('video', {
                'title': item['title'],
                'tvshowtitle': series_name,
                'mediatype': 'episode' 
            })
        
        li_episode.addContextMenuItems([("Smazat z historie", f"RunPlugin({delete_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li_episode, isFolder=False)
            
    xbmcplugin.endOfDirectory(addon_handle)


def build_url(query):
    """Sestaví URL pro volání funkcí pluginu."""
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def get_html(url):
    """Získá HTML obsah z dané URL pomocí cloudscraperu."""
    scraper = cloudscraper.create_scraper()
    try:
        response = scraper.get(url, timeout=10)
        response.raise_for_status()
        log_debug(f"GET {url} → Status {response.status_code}")
        response.encoding = 'utf-8' 
        return response.text
    except requests.exceptions.RequestException as e:
        log_debug(f"Chyba při spojení s {url}: {e}")
        xbmcgui.Dialog().ok("Chyba připojení", "Nepodařilo se spojit se serverem Hellspy.\nZkontrolujte připojení k internetu a zkuste to znovu.")
        raise
    except Exception as e:
        log_debug(f"Neočekávaná chyba v get_html: {e}")
        xbmcgui.Dialog().ok("Chyba", "Došlo k neočekávané chybě při získávání obsahu.")
        raise

def remove_diacritics(text):
    if not isinstance(text, str):
        return text
    normalized_text = unicodedata.normalize('NFD', text)
    stripped_text = ''.join(char for char in normalized_text if unicodedata.category(char) != 'Mn')
    return str(stripped_text)

def extract_episode_info(title):
    """
    Extrahování informací o sezóně a epizodě z názvu.
    Vylepšeno pro robustnější chování a prioritizaci "série/díl" formátů
    a zajištění odstranění diakritiky z názvu.
    Nyní také pokus o získání oficiálního názvu z TMDb.
    """
    original_title = title
    log_debug(f"Vstupní název pro extrakci epizody: '{original_title}'")

    # Krok 1: Normalizace vstupního řetězce
    title_for_regex = re.sub(r'[\s\.\+\-_]+', ' ', title).strip()
    log_debug(f"Normalizovaný název pro regex matching: '{title_for_regex}'")

    # Krok 2: Odstranění běžných formátů rozsahů epizod nebo duplicitních informací
    title_for_regex = re.sub(r'(?i)\b(S?\d{1,2}[xX]\d{1,2})\s*[\+\-]\s*(S?\d{1,2}[xX]\d{1,2})\b', r'\1', title_for_regex)
    
    title_for_regex = re.sub(r'(?i)\bS(\d{1,2})E(\d{1,2})[-–]\d{1,2}\b', r'S\1E\2', title_for_regex)
    title_for_regex = re.sub(r'(?i)\b(S\d{1,2}E\d{1,2})\b.*?\b(\d{1,2}[x\-\.]\d{1,2})\b', r'\1', title_for_regex)
    title_for_regex = re.sub(r'(?i)\b(\d{1,2}[x\-\.]\d{1,2})\b.*?\b(S\d{1,2}E\d{1,2})\b', r'\2', title_for_regex)
    log_debug(f"Vyčištěný název pro regex po odstranění rozsahů/duplicit: '{title_for_regex}'")

    # Krok 3: Definování vzorů s prioritou (od nejpřesnějších po obecnější)
    patterns = [
        r'(?i)(?P<name>.*?)\s+(?P<season>\d{1,2})(?:\s*série|serie)[\s\._-]*?(?:d[ií]l)?\s*(?:d[ií]l)?\s*(?P<episode>\d{1,2})(?:\s*d[ií]l)?(?P<extra>.*)',
        r'(?i)(?P<name>.*?)(?:série|serie)\s*(?P<season>\d{1,2})[\s\._-]*?(?:d[ií]l)\s*(?P<episode>\d{1,2})(?P<extra>.*)',
        r'(?i)(?P<name>.*?)\s*S(?P<season>\d{1,2})E(?P<episode>\d{1,2})(?P<extra>.*)',
        r'(?i)(?P<name>.*?)\s*(?P<season>\d{1,2})[xX](?P<episode>\d{1,2})(?P<extra>.*)',
        r'(?i)(?P<name>.*?)\s*(?P<season>\d{1,2})[\s\._-](?P<episode>\d{1,2})(?!\d)(?P<extra>.*)',
    ]

    extracted_name = None
    extracted_season = "01"
    extracted_episode = "00"
    extracted_extra = ""

    for i, pat in enumerate(patterns):
        match = re.search(pat, title_for_regex)
        if match:
            log_debug(f"Nalezen vzor (index {i}): '{pat}' pro název: '{original_title}'")
            
            log_debug(f"RAW group values for pattern {i}:")
            for group_name in ["name", "season", "episode", "extra"]:
                try:
                    log_debug(f"  {group_name}: '{match.group(group_name)}'")
                except IndexError:
                    log_debug(f"  {group_name}: (Group not found)")
                except KeyError:
                    log_debug(f"  {group_name}: (Named group not present)")

            extracted_name = match.group("name")
            extracted_season = match.group("season").zfill(2)
            extracted_episode = match.group("episode").zfill(2)
            extracted_extra = match.groupdict().get("extra", "")

            break

    # Oprava syntaxe: === nahrazeno ==
    if extracted_name == None:
        extracted_name = title_for_regex
        log_debug(f"Nenalezen žádný vzor pro název: '{original_title}'. Používám fallback název: '{extracted_name}'")

    extracted_name = remove_diacritics(extracted_name)
    log_debug(f"Název po odstranění diakritiky: '{extracted_name}'")

    tmdb_data = search_tmdb(extracted_name)
    if tmdb_data and 'title' in tmdb_data and tmdb_data['title']:
        log_debug(f"TMDb nalezlo lepší název: '{tmdb_data['title']}' pro dotaz '{extracted_name}'.")
        name_for_display = tmdb_data['title']
    else:
        log_debug(f"TMDb nenašlo lepší název pro '{extracted_name}'. Používám původní extrahovaný název.")
        name_for_display = extracted_name


    # Krok 5: Dodatečné čištění extrahovaných skupin
    name_for_display = re.sub(r'[\.\+\-_]+', ' ', name_for_display).strip()
    extracted_extra = re.sub(r'[\.\+\-_]+', ' ', extracted_extra).strip()
    
    extracted_extra = re.sub(r'\s*\.(mkv|avi|mp4|srt|sub|cz|en|sk|dub|orig|titulky|dabing|dvdrip|webrip|hd|fhd|sd|x264|x265|h264|h265)\b.*$', '', extracted_extra, flags=re.IGNORECASE).strip()
    extracted_extra = re.sub(r'\s*\(.*?\)\s*', '', extracted_extra).strip()
    extracted_extra = re.sub(r'\s*\b\d{1,3}\b$', '', extracted_extra).strip()

    log_debug(f"Extrahováno (po finálním čištění a TMDb): Název='{name_for_display}', Sezóna='{extracted_season}', Epizoda='{extracted_episode}', Extra='{extracted_extra}'")
    
    return name_for_display, extracted_season, extracted_episode, extracted_extra

def load_search_cache(cache_key):
    """Načte výsledky hledání z cache."""
    try:
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f:
                cache = json.load(f)
                log_debug(f"Načítám cache pro klíč: {cache_key}")
                return cache.get(cache_key)
    except Exception as e:
        log_debug(f"Chyba při načítání cache hledání: {e}")
    return None

def save_search_cache(cache_key, data):
    """Uloží výsledky hledání do cache."""
    try:
        cache_dir = os.path.dirname(search_cache_file)
        if not xbmcvfs.exists(cache_dir):
            xbmcvfs.mkdirs(cache_dir)
        cache = {}
        if xbmcvfs.exists(search_cache_file):
            with open(search_cache_file, "r", encoding="utf-8") as f:
                cache = json.load(f)
        cache[cache_key] = data
        if len(cache) > 10:
            cache = dict(list(cache.items())[-10:])
        with open(search_cache_file, "w", encoding="utf-8") as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
        log_debug(f"Uložena cache pro klíč: {cache_key}")
    except Exception as e:
        log_debug(f"Chyba při ukládání cache hledání: {e}")

def clear_search_cache():
    """Vymaže cache výsledků hledání."""
    try:
        if xbmcvfs.exists(search_cache_file):
            xbmcvfs.delete(search_cache_file)
            log_debug("Cache výsledků hledání vymazána.")
    except Exception as e:
        log_debug(f"Chyba při mazání cache: {e}")

def list_main_menu():
    """Zobrazí hlavní menu pluginu."""
    # Pořadí hlavního menu: Vyhledat, Filmy, Seriály, Historie sledování, Historie vyhledávání

    # Vyhledat
    url = build_url({'mode': 'search'})
    li = xbmcgui.ListItem(label='Vyhledat')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # Filmy
    url = build_url({'mode': 'list_movies_menu'})
    li = xbmcgui.ListItem(label='Filmy')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # Seriály
    url = build_url({'mode': 'list_series_menu'})
    li = xbmcgui.ListItem(label='Seriály')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # Historie sledování
    url = build_url({'mode': 'watch_history'})
    li = xbmcgui.ListItem(label='Historie sledování')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    # Historie hledání
    url = build_url({'mode': 'history'})
    li = xbmcgui.ListItem(label='Historie hledání')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(addon_handle, updateListing=False, cacheToDisc=False)

def list_movies_menu():
    """Zobrazí podsložky pro filmy."""
    
    # Položka pro návrat DOMŮ (HLAVNÍ MENU)
    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    url = build_url({'mode': 'movies_top_rated'})
    li = xbmcgui.ListItem(label='Nejlépe hodnocené')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'movies_popular'})
    li = xbmcgui.ListItem(label='Oblíbené')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'movies_now_playing'})
    li = xbmcgui.ListItem(label='Právě se vysílá')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'movies_genres'})
    li = xbmcgui.ListItem(label='Žánry')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'movies_by_year'})
    li = xbmcgui.ListItem(label='Rok')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    
    url = build_url({'mode': 'prompt_tmdb_search', 'media_type': 'movie'})
    li = xbmcgui.ListItem(label='Vyhledat') # Změněno z 'Vyhledat na TMDb'
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

def list_series_menu():
    """Zobrazí podsložky pro seriály."""

    # Položka pro návrat DOMŮ (HLAVNÍ MENU)
    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    url = build_url({'mode': 'series_top_rated'})
    li = xbmcgui.ListItem(label='Nejlépe hodnocené')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'series_popular'})
    li = xbmcgui.ListItem(label='Oblíbené')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'series_airing_today'})
    li = xbmcgui.ListItem(label='Právě se vysílá')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'series_genres'})
    li = xbmcgui.ListItem(label='Žánry')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'series_by_year'})
    li = xbmcgui.ListItem(label='Rok')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    url = build_url({'mode': 'prompt_tmdb_search', 'media_type': 'tv'})
    li = xbmcgui.ListItem(label='Vyhledat') # Změněno z 'Vyhledat na TMDb'
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle)

    
def list_history():
    """Zobrazí historii hledání v Kodi."""
    history = load_query_history()
    if not history:
        xbmcgui.Dialog().ok("Historie hledání", "Historie hledání je prázdná.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    # Položka pro návrat DOMŮ (HLAVNÍ MENU) - ODEBRÁNO DLE POŽADAVKU UŽIVATELE

    for item in history:
        if '|' in item:
            query, count = item.split('|', 1)
        else:
            query, count = item, '?'
        search_url = build_url({'mode': 'repeat_search', 'query': query})
        remove_url = build_url({'mode': 'delete_history_item', 'query': query})
        li = xbmcgui.ListItem(label=f"{query} ({count})")
        li.addContextMenuItems([("Smazat z historie", f"RunPlugin({remove_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def list_top_rated_movies():
    """Zobrazí seznam nejlépe hodnocených filmů z TMDb."""
    log_debug("Načítám nejlépe hodnocené filmy z TMDb.")
    xbmcplugin.setContent(addon_handle, 'movies')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_movies_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Filmy[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1}
    data = _get_tmdb_data('/movie/top_rated', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst nejlépe hodnocené filmy z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for movie in data['results']:
        title = movie.get('title')
        overview = movie.get('overview')
        poster_path = movie.get('poster_path')
        release_date = movie.get('release_date', '')
        year = release_date.split('-')[0] if release_date else ''

        if not title:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'movie'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        search_hellspy_url = build_url({'mode': 'repeat_search', 'query': title})
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_hellspy_url, listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny nejlépe hodnocené filmy z TMDb.")

def list_popular_movies():
    """Zobrazí seznam oblíbených filmů z TMDb."""
    log_debug("Načítám oblíbené filmy z TMDb.")
    xbmcplugin.setContent(addon_handle, 'movies')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_movies_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Filmy[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1}
    data = _get_tmdb_data('/movie/popular', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst oblíbené filmy z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for movie in data['results']:
        title = movie.get('title')
        overview = movie.get('overview')
        poster_path = movie.get('poster_path')
        release_date = movie.get('release_date', '')
        year = release_date.split('-')[0] if release_date else ''

        if not title:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'movie'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        search_hellspy_url = build_url({'mode': 'repeat_search', 'query': title})
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_hellspy_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny oblíbené filmy z TMDb.")

def list_now_playing_movies():
    """Zobrazí seznam filmů, které jsou právě v kinech (now playing) z TMDb."""
    log_debug("Načítám právě se vysílající filmy z TMDb.")
    xbmcplugin.setContent(addon_handle, 'movies')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_movies_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Filmy[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1, 'region': 'CZ'}
    data = _get_tmdb_data('/movie/now_playing', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst právě se vysílající filmy z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for movie in data['results']:
        title = movie.get('title')
        overview = movie.get('overview')
        poster_path = movie.get('poster_path')
        release_date = movie.get('release_date', '')
        year = release_date.split('-')[0] if release_date else ''

        if not title:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'movie'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        search_hellspy_url = build_url({'mode': 'repeat_search', 'query': title})
        
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_hellspy_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny právě se vysílající filmy z TMDb.")


def list_top_rated_series():
    """Zobrazí seznam nejlépe hodnocených seriálů z TMDb."""
    log_debug("Načítám nejlépe hodnocené seriály z TMDb.")
    xbmcplugin.setContent(addon_handle, 'tvshows')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_series_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Seriály[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1}
    data = _get_tmdb_data('/tv/top_rated', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst nejlépe hodnocené seriály z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for series in data['results']:
        title = series.get('name')
        overview = series.get('overview')
        poster_path = series.get('poster_path')
        first_air_date = series.get('first_air_date', '')
        year = first_air_date.split('-')[0] if first_air_date else ''
        tmdb_id = series.get('id')

        if not title or not tmdb_id:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'tvshow'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        series_detail_url = build_url({'mode': 'list_tmdb_series_seasons', 'tmdb_id': tmdb_id, 'series_name': title})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_detail_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny nejlépe hodnocené seriály z TMDb.")

def list_popular_series():
    """Zobrazí seznam oblíbených seriálů z TMDb."""
    log_debug("Načítám oblíbené seriály z TMDb.")
    xbmcplugin.setContent(addon_handle, 'tvshows')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_series_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Seriály[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1}
    data = _get_tmdb_data('/tv/popular', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst oblíbené seriály z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for series in data['results']:
        title = series.get('name')
        overview = series.get('overview')
        poster_path = series.get('poster_path')
        first_air_date = series.get('first_air_date', '')
        year = first_air_date.split('-')[0] if first_air_date else ''
        tmdb_id = series.get('id')

        if not title or not tmdb_id:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'tvshow'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        series_detail_url = build_url({'mode': 'list_tmdb_series_seasons', 'tmdb_id': tmdb_id, 'series_name': title})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_detail_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny oblíbené seriály z TMDb.")

def list_airing_today_series():
    """Zobrazí seznam seriálů, které jsou dnes vysílány (airing today) z TMDb."""
    log_debug("Načítám dnes vysílané seriály z TMDb.")
    xbmcplugin.setContent(addon_handle, 'tvshows')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'list_series_menu'})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na Seriály[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    params = {'page': 1, 'region': 'CZ'}
    data = _get_tmdb_data('/tv/airing_today', params)

    if not data or 'results' not in data:
        xbmcgui.Dialog().ok("Chyba", "Nepodařilo se načíst dnes vysílané seriály z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for series in data['results']:
        title = series.get('name')
        overview = series.get('overview')
        poster_path = series.get('poster_path')
        first_air_date = series.get('first_air_date', '')
        year = first_air_date.split('-')[0] if first_air_date else ''
        tmdb_id = series.get('id')

        if not title or not tmdb_id:
            continue

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{title} ({year})" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': 'tvshow'
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        series_detail_url = build_url({'mode': 'list_tmdb_series_seasons', 'tmdb_id': tmdb_id, 'series_name': title})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_detail_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug("Zobrazeny dnes vysílané seriály z TMDb.")


def list_tmdb_series_seasons(tmdb_id, series_name, query=None): # Přidán parametr 'query'
    """Zobrazí seznam sezón pro daný seriál z TMDb."""
    log_debug(f"Načítám sezóny pro TMDb seriál: '{series_name}' (ID: {tmdb_id}).")
    xbmcplugin.setContent(addon_handle, 'seasons')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    # Změna URL pro tlačítko "Zpět"
    # Nyní vždy vede zpět do hlavního menu seriálů.
    back_url = build_url({'mode': 'list_series_menu'})
    li_back = xbmcgui.ListItem(label=f"[B][COLOR lightblue]← Zpět na Seriály[/COLOR][/B]")

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    data = _get_tmdb_data(f'/tv/{tmdb_id}', {})

    if not data or 'seasons' not in data:
        xbmcgui.Dialog().ok("Chyba", f"Nepodařilo se načíst sezóny pro seriál '{series_name}' z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for season in data['seasons']:
        season_number = season.get('season_number')
        season_name = season.get('name')
        episode_count = season.get('episode_count')
        poster_path = season.get('poster_path')
        overview = season.get('overview')

        if season_number is None or season_name is None:
            continue
        
        if season_number == 0:
            season_display_name = "Speciály"
        else:
            season_display_name = f"Série {season_number}"

        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""

        list_item_label = f"{series_name} - {season_display_name} ({episode_count} dílů)"
        li = xbmcgui.ListItem(label=list_item_label)

        li.setInfo('video', {
            'title': season_name,
            'season': season_number,
            'plot': overview,
            'mediatype': 'season',
            'tvshowtitle': series_name
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        season_url = build_url({
            'mode': 'list_tmdb_season_episodes',
            'tmdb_id': tmdb_id,
            'season_number': season_number,
            'series_name': series_name,
            'query': query # Předání 'query' do další úrovně
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=season_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeny sezóny pro seriál: '{series_name}'.")

def list_tmdb_season_episodes(tmdb_id, season_number, series_name, query=None): # Přidán parametr 'query'
    """Zobrazí seznam epizod pro danou sezónu seriálu z TMDb."""
    log_debug(f"Načítám epizody pro TMDb seriál: '{series_name}' (ID: {tmdb_id}), sezóna: {season_number}.")
    xbmcplugin.setContent(addon_handle, 'episodes')

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    # Změna URL pro tlačítko "Zpět"
    back_url = build_url({'mode': 'list_tmdb_series_seasons', 'tmdb_id': tmdb_id, 'series_name': series_name, 'query': query if query else ''}) # Předání 'query' zpět
    li_back = xbmcgui.ListItem(label=f"[B][COLOR lightblue]← Zpět na sezóny {series_name}[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    data = _get_tmdb_data(f'/tv/{tmdb_id}/season/{season_number}', {})

    if not data or 'episodes' not in data:
        xbmcgui.Dialog().ok("Chyba", f"Nepodařilo se načíst epizody pro sezónu {season_number} seriálu '{series_name}' z TMDb.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    for episode in data['episodes']:
        episode_number = episode.get('episode_number')
        episode_name = episode.get('name')
        overview = episode.get('overview')
        still_path = episode.get('still_path')

        if episode_number is None or episode_name is None:
            continue

        full_still_url = f"{TMDB_IMAGE_BASE_URL}{still_path}" if still_path else ""

        hellspy_search_query = f"{series_name} S{season_number:02d}E{episode_number:02d}"
        
        list_item_label = f"{series_name} - S{season_number:02d}E{episode_number:02d} - {episode_name}" 
        li = xbmcgui.ListItem(label=list_item_label)

        li.setInfo('video', {
            'title': episode_name,
            'season': season_number,
            'episode': episode_number,
            'plot': overview,
            'mediatype': 'episode',
            'tvshowtitle': series_name
        })
        
        li.setArt({
            'thumb': full_still_url,
            'icon': full_still_url,
            'poster': full_still_url
        })
        play_url = build_url({
            'mode': 'repeat_search',
            'query': hellspy_search_query,
            'is_tmdb_episode_search': 'True',
            'tmdb_id': tmdb_id,
            'season_number': season_number,
            'series_name': series_name
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeny epizody pro seriál: '{series_name}', sezóna: {season_number}.")


def list_search_results(query, page=1, is_tmdb_episode_search=False, tmdb_id_for_back=None, season_number_for_back=0, series_name_for_back=None):
    """
    Získává výsledky hledání z Hellspy.to, zpracuje je,
    a zobrazí je buď přímo (pro specifické epizody z TMDb),
    nebo seskupí seriály do složek a zobrazí filmy (pro obecné vyhledávání).
    """
    log_debug(f"Spouštím list_search_results pro dotaz: '{query}', stránka: {page}, z TMDb epizody: {is_tmdb_episode_search}")

    cache_key = hashlib.md5(query.encode('utf-8')).hexdigest()
    cached_data = load_search_cache(cache_key) 

    processed_items = []
    total_items = 0

    if cached_data:
        processed_items = cached_data
        total_items = len(processed_items)
        log_debug(f"Používám cached výsledky pro '{query}'. Celkem: {total_items} položek.")
    else:
        all_items_from_hellspy = []
        
        progress = xbmcgui.DialogProgress()
        progress.create("Hledání na Hellspy", f"Načítám výsledky pro: {query}")

        try:
            log_debug(f"Načítám výsledky z Hellspy.to pro dotaz: '{query}'")
            progress.update(0, "Načítám výsledky z Hellspy.to...")
            
            hellspy_search_url = f"{base_url}/?query={urllib.parse.quote(query)}&page=1"
            
            try:
                html = get_html(hellspy_search_url)
                soup = BeautifulSoup(html, "html.parser")
                items = soup.select('.result-video')

                if items:
                    all_items_from_hellspy.extend(items)
                else:
                    log_debug(f"Nenalezeny žádné video položky na Hellspy.to pro dotaz: {query}")

                progress.update(100, "Načítání dokončeno.")
                xbmc.sleep(300)
            except Exception as e:
                log_debug(f"Chyba při načítání výsledků z Hellspy.to: {e}")
                xbmcgui.Dialog().ok("Chyba", f"Nepodařilo se načíst výsledky z Hellspy.to pro '{query}'.")
                
        finally:
            progress.close()

        if progress.iscanceled():
            xbmc.executebuiltin("Container.Refresh")
            return

        if not all_items_from_hellspy:
            xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyl nalezen žádný výslepek.")
            if is_tmdb_episode_search and tmdb_id_for_back and season_number_for_back and series_name_for_back:
                xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'list_tmdb_season_episodes', 'tmdb_id': tmdb_id_for_back, 'season_number': season_number_for_back, 'series_name': series_name_for_back})})")
            else:
                xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
            return

        seen_original_titles = set()
        for item_html in all_items_from_hellspy:
            try:
                title = item_html.get("title", "").strip()
                href = item_html.get("href", "")
                img_tag = item_html.find("img")
                thumbnail = img_tag["src"] if img_tag and "src" in img_tag.attrs else ""

                if title in seen_original_titles:
                    log_debug(f"Duplicitní název '{title}' nalezen, přeskočeno.")
                    continue
                seen_original_titles.add(title)

                video_id_match = re.search(r'/video/(\d+/\d+)', href)
                video_id = video_id_match.group(1) if video_id_match else hashlib.md5(href.encode('utf-8')).hexdigest()

                video_page_url = urllib.parse.urljoin(base_url, href)
                
                name, season, episode, extra = extract_episode_info(title)

                processed_items.append({
                    'original_name': name,
                    'season': int(season),
                    'episode': int(episode),
                    'extra': extra,
                    'video_page_url': video_page_url,
                    'thumbnail': thumbnail,
                    'original_title': title,
                    'id': video_id,
                    'is_series': int(episode) > 0 
                })
            except Exception as e:
                log_debug(f"Chyba při zpracování položky Hellspy: {e}")
                continue

        processed_items.sort(key=lambda x: (
            x['original_name'].lower(),
            x['season'],
            x['episode']
        ))
        save_search_cache(cache_key, processed_items)
    
    total_items = len(processed_items)

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    if is_tmdb_episode_search and tmdb_id_for_back and season_number_for_back and series_name_for_back:
        back_url_for_results = build_url({
            'mode': 'list_tmdb_season_episodes',
            'tmdb_id': tmdb_id_for_back,
            'season_number': season_number_for_back,
            'series_name': series_name_for_back
        })
        li_back = xbmcgui.ListItem(label=f"[B][COLOR lightblue]← Zpět na epizody {series_name_for_back} S{season_number_for_back:02d}[/COLOR][/B]")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url_for_results, listitem=li_back, isFolder=True)
    
    if is_tmdb_episode_search:
        xbmcplugin.setContent(addon_handle, 'episodes')
        for item in processed_items:
            formatted_title = item['original_title'] 
            if not re.search(r'S\d{2}E\d{2}', formatted_title, re.IGNORECASE):
                 formatted_title = f"{item['original_name']} - S{item['season']:02d}E{item['episode']:02d} - {formatted_title}"
            if item['extra']:
                extra_clean = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
                if extra_clean and not extra_clean.lower() in formatted_title.lower(): 
                    formatted_title += f" - {extra_clean}"

            li = xbmcgui.ListItem(label=formatted_title)
            li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
            li.setInfo("video", {
                "title": formatted_title,
                "plot": f"Přehrát: {formatted_title}",
                "tvshowtitle": item['original_name'],
                "season": item['season'],
                "episode": item['episode']
            })
            li.setProperty("IsPlayable", "true")
            play_url_hellspy = build_url({'mode': 'play', 'url': item['video_page_url'], 'display_title': formatted_title, 'thumbnail': item['thumbnail']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url_hellspy, listitem=li, isFolder=False)
        log_debug(f"Zobrazeny přímé výsledky Hellspy pro dotaz '{query}'.")

    else:
        series_items = defaultdict(list)
        movie_items = []

        for item in processed_items:
            if item.get('is_series'):
                series_items[item['original_name']].append(item)
            else:
                movie_items.append(item)

        xbmcplugin.setContent(addon_handle, 'tvshows')
        sorted_series_names = sorted(series_items.keys())
        for series_name_key in sorted_series_names: 
            if series_items[series_name_key]:
                first_item_in_series = series_items[series_name_key][0]
                series_thumbnail = first_item_in_series['thumbnail']
            else:
                series_thumbnail = ""

            li = xbmcgui.ListItem(label=f"[B][COLOR orange]{series_name_key}[/COLOR][/B]")
            li.setArt({"thumb": series_thumbnail, "icon": series_thumbnail, "poster": series_thumbnail})
            li.setInfo("video", {
                "title": series_name_key,
                "tvshowtitle": series_name_key,
                "plot": f"Složka pro seriál {series_name_key}."
            })
            
            series_folder_url = build_url({
                'mode': 'list_series_seasons',
                'series_name': series_name_key,
                'query': query
            })
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_folder_url, listitem=li, isFolder=True)

        xbmcplugin.setContent(addon_handle, 'movies')
        movie_items.sort(key=lambda x: x['original_name'].lower())

        for item in movie_items:
            final_name = item['original_name']
            formatted_title = final_name.strip()
            if item['extra']:
                extra_clean = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
                if extra_clean:
                    formatted_title += f" - {extra_clean}"

            li = xbmcgui.ListItem(label=formatted_title)
            li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
            li.setInfo("video", {
                "title": formatted_title,
                "plot": f"Film: {formatted_title}"
            })
            li.setProperty("IsPlayable", "true")

            play_url_hellspy = build_url({'mode': 'play', 'url': item['video_page_url'], 'display_title': formatted_title, 'thumbnail': item['thumbnail']})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url_hellspy, listitem=li, isFolder=False)
        log_debug(f"Zobrazeny výsledky hledání: {len(sorted_series_names)} seriálů a {len(movie_items)} filmů pro dotaz '{query}'.")

    save_query_to_history(query, total_items)
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)

def list_series_seasons(series_name, query):
    """
    Zobrazí seznam sezón pro daný seriál.
    """
    log_debug(f"Spouštím list_series_seasons pro seriál: '{series_name}', původní dotaz: '{query}'")
    xbmcplugin.setContent(addon_handle, 'seasons')

    cache_key = hashlib.md5(query.encode('utf-8')).hexdigest()
    processed_items = load_search_cache(cache_key)

    if not processed_items:
        log_debug(f"Cache pro dotaz '{query}' nenalezena při pokusu o zobrazení sezón.")
        xbmcgui.Dialog().ok("Chyba", "Data pro seriál nejsou k dispozici. Prosím, zkuste hledat znovu.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    seasons_data = defaultdict(list)
    for item in processed_items:
        if item.get('original_name') == series_name and item.get('episode', 0) > 0:
            seasons_data[item['season']].append(item)

    sorted_seasons = sorted(seasons_data.keys())

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_url = build_url({'mode': 'repeat_search', 'query': query, 'page': 1})
    li_back = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na výsledky hledání[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)


    for season_number in sorted_seasons:
        first_episode_in_season = seasons_data[season_number][0]
        season_folder_title = f"{series_name} - Série {season_number:02d}"
        
        li = xbmcgui.ListItem(label=season_folder_title)
        li.setArt({"thumb": first_episode_in_season['thumbnail'], "icon": first_episode_in_season['thumbnail'], "poster": first_episode_in_season['thumbnail']})
        li.setInfo("video", {
            "title": season_folder_title,
            "tvshowtitle": series_name,
            "season": season_number,
            "plot": f"Složka pro {series_name} - Série {season_number:02d}"
        })
        
        season_url = build_url({
            'mode': 'list_season_episodes',
            'series_name': series_name,
            'season_number': season_number,
            'query': query
        })
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=season_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeno {len(sorted_seasons)} sezón pro seriál: '{series_name}'.")

def list_season_episodes(series_name, season_number, query):
    """
    Zobrazí seznam epizod pro daný seriál a sezónu.
    """
    log_debug(f"Spouštím list_season_episodes pro seriál: '{series_name}', sezóna: {season_number}, původní dotaz: '{query}'")
    xbmcplugin.setContent(addon_handle, 'episodes')

    cache_key = hashlib.md5(query.encode('utf-8')).hexdigest()
    processed_items = load_search_cache(cache_key)

    if not processed_items:
        log_debug(f"Cache pro dotaz '{query}' nenalezena při pokusu o zobrazení epizod.")
        xbmcgui.Dialog().ok("Chyba", "Data pro epizody nejsou k dispozici. Prosím, zkuste hledat znovu.")
        xbmcplugin.endOfDirectory(addon_handle, succeeded=False)
        return

    episodes_in_season = []
    for item in processed_items:
        if item.get('original_name') == series_name and item.get('season') == season_number and item.get('episode', 0) > 0:
            episodes_in_season.append(item)

    episodes_in_season.sort(key=lambda x: x['episode'])

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    back_to_seasons_url = build_url({'mode': 'list_series_seasons', 'series_name': series_name, 'query': query})
    li_back_seasons = xbmcgui.ListItem(label="[B][COLOR lightblue]← Zpět na seznam sezón[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_to_seasons_url, listitem=li_back_seasons, isFolder=True)


    for item in episodes_in_season:
        final_name = item['original_name']
        formatted_title = f"{final_name} - S{item['season']:02d}E{item['episode']:02d}"
        if item['extra']:
            extra_clean = re.sub(r'[\.\+\-_]+', ' ', item['extra']).strip()
            if extra_clean:
                formatted_title += f" - {extra_clean}"

        li = xbmcgui.ListItem(label=formatted_title)
        li.setArt({"thumb": item['thumbnail'], "icon": item['thumbnail'], "poster": item['thumbnail']})
        li.setInfo("video", {
            "title": formatted_title,
            "tvshowtitle": final_name,
            "season": item['season'],
            "episode": item['episode'],
        })
        li.setProperty("IsPlayable", "true")
        
        play_url = build_url({'mode': 'play', 'url': item['video_page_url'], 'display_title': formatted_title, 'thumbnail': item['thumbnail']})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeno {len(episodes_in_season)} epizod pro sezónu {season_number} seriálu: '{series_name}'.")

def play_video(url, display_title="Neznámý název", thumbnail_url=""):
    """
    Přehrává video z dané URL stránky.
    Extrahování přímého odkazu na video ze stránky Hellspy.
    Nyní ukládá název zobrazený uživateli do historie sledování a podporuje titulky.
    """
    log_debug(f"Pokouším se přehrát video z URL: {url}")
    try:
        html = get_html(url)
    except Exception:
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())
        return

    video_url = None
    available_subtitles = []

    matches = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html)
    log_debug(f"Nalezeno {len(matches)} potenciálních JSON bloků pro video URL a titulky.")

    for i, raw_string in enumerate(matches):
        try:
            decoded_str = bytes(raw_string, "utf-8").decode("unicode_escape")
            log_debug(f"Zpracovávám blok {i+1}: Dekódovaný string začíná: {decoded_str[:100]}...")

            match = re.search(r'"initialVideo"\s*:\s*(\{.*?\})\s*,\s*"initialVideoId"', decoded_str, re.DOTALL)
            if not match:
                log_debug(f"Blok {i+1}: Regex pro 'initialVideo' se nezdařil.")
                continue

            video_json_str = match.group(1)
            log_debug(f"Blok {i+1}: Extrahována část JSONu pro 'initialVideo': {video_json_str[:200]}...")

            video_json = json.loads(video_json_str)
            log_debug(f"Blok {i+1}: JSON úspěšně parsován.")

            conversions = video_json.get("conversions", {})
            log_debug(f"Dostupné konverze (video kvality): {list(conversions.keys())}")

            subtitles_data = video_json.get("subtitles", [])
            if subtitles_data:
                log_debug(f"Nalezeny titulky v JSONu: {subtitles_data}")
                for sub in subtitles_data:
                    if isinstance(sub, dict) and "src" in sub and "label" in sub:
                        available_subtitles.append({"url": sub["src"], "label": sub["label"]})
                        log_debug(f"Přidán titulek: {sub['label']} - {sub['src']}")
                    elif isinstance(sub, str) and sub.startswith(('http://', 'https://')):
                        label = "Neznámý jazyk"
                        if "cs.srt" in sub.lower() or "czech.srt" in sub.lower():
                            label = "Čeština"
                        elif "en.srt" in sub.lower() or "english.srt" in sub.lower():
                            label = "Angličtina"
                        available_subtitles.append({"url": sub, "label": label})
                        log_debug(f"Přidán titulek (URL only): {label} - {sub}")
            else:
                log_debug("V JSONu 'initialVideo' nebyly nalezeny žádné titulky.")

            quality_order = ["1080", "720", "480", "360", "240"]
            for quality in quality_order:
                if quality in conversions and conversions[quality]:
                    video_url = conversions[quality]
                    log_debug(f"Vybrána kvalita {quality}: {video_url}")
                    break

            if not video_url:
                for key, value in conversions.items():
                    if value:
                        video_url = value
                        log_debug(f"Fallback: Použita kvalita '{key}': {video_url}")
                        break

            if not video_url:
                alt_keys = ["url", "src", "source", "file", "mp4"]
                for key in alt_keys:
                    if key in video_json and video_json[key]:
                        video_url = video_json[key]
                        log_debug(f"Fallback: Nalezen alternativní klíč '{key}': {video_url}")
                        break

            if not video_url:
                log_debug(f"Blok {i+1}: V 'initialVideo' JSONu nebyla nalezena žádná platná video URL.")
                log_debug(f"Celý JSON 'initialVideo': {json.dumps(video_json, indent=2)}")
                continue

            if not video_url.startswith(('http://', 'https://')):
                log_debug(f"Blok {i+1}: Nalezená URL není platná HTTP/HTTPS adresa: {video_url}")
                continue

            if not display_title or display_title == "Neznámý název":
                 log_debug(f"display_title není k dispozici, používám název z JSONu videa: '{video_json.get('title', 'Neznámý název')}'")
                 display_title = video_json.get("title", "Neznámý název")
            
            if not thumbnail_url:
                thumbnail_url = video_json.get("poster", "") or video_json.get("thumbnail", "")
                if thumbnail_url:
                    log_debug(f"Thumbnail URL získána z video_json: '{thumbnail_url}'")
            
            break

        except json.JSONDecodeError as e:
            log_debug(f"Blok {i+1}: Chyba při parsování JSONu: {e}")
            continue
        except Exception as e:
            log_debug(f"Blok {i+1}: Obecná chyba při zpracování bloku: {e}")
            continue

    if not video_url:
        log_debug("Nepodařilo se najít žádnou streamovací URL po prohledání všech bloků.")
        soup = BeautifulSoup(html, "html.parser")
        video_tags = soup.find_all("video")
        if video_tags:
            for video in video_tags:
                src = video.get("src") or (video.find("source") and video.find("source").get("src"))
                if src and src.startswith(('http://', 'https://')):
                    video_url = src
                    if not display_title or display_title == "Neznámý název":
                        display_title = "Video z HTML tagu" 
                    log_debug(f"Nalezen video tag s src: {src}")
                    break
        
    if video_url:
        save_watch_history_entry(url, display_title, thumbnail_url)

        mime_type = "video/mp4"
        if video_url.endswith('.m3u8'):
            mime_type = "application/vnd.apple.mpegurl"
        elif video_url.endswith('.webm'):
            mime_type = "video/webm"
        elif video_url.endswith('.avi'):
            mime_type = "video/x-msvideo"
        
        listitem = xbmcgui.ListItem(path=video_url)
        listitem.setMimeType(mime_type)
        listitem.setProperty("IsPlayable", "true")
        listitem.setContentLookup(False)

        if not ("User-Agent=" in video_url) and base_url in video_url:
            video_url += "|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
            listitem.setPath(video_url)
            
        if available_subtitles:
            log_debug(f"Celkem nalezeno {len(available_subtitles)} titulků.")
            if len(available_subtitles) == 1:
                listitem.setSubtitles([available_subtitles[0]["url"]])
                log_debug(f"Automaticky nastaven titulek: {available_subtitles[0]['label']} ({available_subtitles[0]['url']})")
            else:
                dialog_options = [sub["label"] for sub in available_subtitles]
                dialog_options.insert(0, "Žádné titulky")
                
                selected_index = xbmcgui.Dialog().select("Vyberte titulky", dialog_options)
                
                if selected_index > 0:
                    selected_subtitle_url = available_subtitles[selected_index - 1]["url"]
                    listitem.setSubtitles([selected_subtitle_url])
                    log_debug(f"Uživatel vybral titulek: {available_subtitles[selected_index - 1]['label']} ({selected_subtitle_url})")
                else:
                    log_debug("Uživatel nezvolil žádné titulky nebo zrušil výběr.")
                    listitem.setSubtitles([])
        else:
            log_debug("Pro toto video nebyly nalezeny žádné titulky.")
            listitem.setSubtitles([])

        xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
        log_debug(f"Streamování videa: {video_url}")
    else:
        xbmcgui.Dialog().ok("Chyba přehrávání", "Nepodařilo se získat přímý odkaz na video.\nZkontrolujte logy pro více informací.")
        xbmcplugin.setResolvedUrl(addon_handle, False, xbmcgui.ListItem())

def prompt_tmdb_search(media_type):
    """
    Vyzve uživatele k zadání vyhledávacího dotazu pro TMDb.
    media_type: 'movie' nebo 'tv' pro určení, ze kterého menu bylo vyhledávání spuštěno.
    """
    xbmcplugin.endOfDirectory(addon_handle, updateListing=False)
    keyboard = xbmcgui.Dialog().input("Zadejte hledaný výraz (TMDb)", type=xbmcgui.INPUT_ALPHANUM)
    if keyboard:
        xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'tmdb_search_results', 'query': keyboard, 'media_type': media_type})})")
    else:
        # Změna: Pokud uživatel zruší, vrátí se do menu Filmy/Seriály, ne do hlavního menu
        if media_type == 'movie':
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'list_movies_menu'})})")
        else:
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'list_series_menu'})})")


def tmdb_search_results(query, media_type):
    """
    Zobrazí výsledky vyhledávání z TMDb a umožní přejít na Hellspy.
    query: hledaný výraz
    media_type: 'movie' nebo 'tv' (původní typ vyhledávání pro navigační účely)
    """
    log_debug(f"Spouštím tmdb_search_results pro dotaz: '{query}', typ: '{media_type}'")

    main_url = build_url({'mode': 'main'})
    li_home = xbmcgui.ListItem(label="[B][COLOR yellow]Domů[/COLOR][/B]")
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=main_url, listitem=li_home, isFolder=True)

    # Změněno: Tlačítko Zpět nyní vede na hlavní menu seriálů, pokud je media_type 'tv'
    if media_type == 'tv':
        back_url = build_url({'mode': 'list_series_menu'})
        li_back = xbmcgui.ListItem(label=f"[B][COLOR lightblue]← Zpět na Seriály[/COLOR][/B]")
    else: # pro filmy nebo jiné typy zpět na vyhledávání TMDb
        back_url = build_url({'mode': 'prompt_tmdb_search', 'media_type': media_type})
        li_back = xbmcgui.ListItem(label=f"[B][COLOR lightblue]← Zpět na vyhledávání { 'filmů' if media_type == 'movie' else 'seriálů'}[/COLOR][/B]")
    
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=back_url, listitem=li_back, isFolder=True)

    tmdb_results = search_tmdb_filtered_list(query, media_type_filter=media_type)

    if not tmdb_results:
        xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyly na TMDb nalezeny žádné výsledky typu '{media_type}'.")
        xbmcplugin.endOfDirectory(addon_handle)
        return

    if media_type == 'movie':
        xbmcplugin.setContent(addon_handle, 'movies')
    else:
        xbmcplugin.setContent(addon_handle, 'tvshows')

    for result in tmdb_results:
        title = result.get('title')
        overview = result.get('overview', 'Popis není k dispozici.')
        poster_path = result.get('poster')
        full_poster_url = f"{TMDB_IMAGE_BASE_URL}{poster_path}" if poster_path else ""
        tmdb_id = result.get('tmdb_id')
        item_type = result.get('type')
        year = result.get('year', '')

        # Upravené zobrazení: rok vydání a poté název
        list_item_label = f"{year} {title}" if year else title
        li = xbmcgui.ListItem(label=list_item_label)
        
        li.setInfo('video', {
            'title': title,
            'year': int(year) if year else 0,
            'plot': overview,
            'mediatype': item_type,
            'tvshowtitle': title if item_type == 'tv' else ''
        })
        
        li.setArt({
            'thumb': full_poster_url,
            'icon': full_poster_url,
            'poster': full_poster_url
        })
        
        if item_type == 'movie':
            hellspy_search_url = build_url({'mode': 'repeat_search', 'query': title})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=hellspy_search_url, listitem=li, isFolder=True)
        elif item_type == 'tv':
            # Předáváme původní 'query' dál, aby se umožnila správná navigace zpět na výsledky vyhledávání
            series_detail_url = build_url({'mode': 'list_tmdb_series_seasons', 'tmdb_id': tmdb_id, 'series_name': title, 'query': query})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=series_detail_url, listitem=li, isFolder=True)
    
    xbmcplugin.endOfDirectory(addon_handle, succeeded=True, updateListing=False, cacheToDisc=True)
    log_debug(f"Zobrazeny všechny relevantní výsledky TMDb vyhledávání pro dotaz: '{query}'.")


def router(paramstring):
    """Router pro zpracování různých módů pluginu."""
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')

    if mode == 'search':
        xbmcplugin.endOfDirectory(addon_handle, updateListing=False)
        keyboard = xbmcgui.Dialog().input("Zadejte hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
        if keyboard:
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'repeat_search', 'query': keyboard, 'page': 1})})")
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
    elif mode == 'repeat_search':
        page = int(params.get('page', 1))
        query = params['query']
        is_tmdb_episode_search = params.get('is_tmdb_episode_search') == 'True'
        tmdb_id_for_back = params.get('tmdb_id')
        season_number_for_back = int(params.get('season_number', 0))
        series_name_for_back = params.get('series_name')
        list_search_results(query, page, is_tmdb_episode_search, tmdb_id_for_back, season_number_for_back, series_name_for_back)
    elif mode == 'list_series_seasons':
        series_name = params['series_name']
        query = params['query']
        list_series_seasons(series_name, query)
    elif mode == 'list_season_episodes':
        series_name = params['series_name']
        season_number = int(params['season_number'])
        query = params['query']
        list_season_episodes(series_name, season_number, query)
    elif mode == 'delete_history_item':
        delete_query_from_history(params['query'])
        xbmc.executebuiltin(f"Container.Refresh")
    elif mode == 'history':
        list_history()
    elif mode == 'watch_history':
        list_watch_history()
    elif mode == 'list_watch_history_movies': 
        list_watch_history_movies()
    elif mode == 'list_watch_history_series': 
        list_watch_history_series()
    elif mode == 'list_watch_history_series_episodes': 
        series_name = params['series_name']
        list_watch_history_series_episodes(series_name)
    elif mode == 'delete_watch_history_item': 
        video_id = params['video_id']
        media_type = params['media_type']
        delete_watch_history_item(video_id, media_type)
    elif mode == 'play':
        play_video(params['url'], params.get('display_title'), params.get('thumbnail')) 
    elif mode == 'main':
        clear_search_cache()
        list_main_menu()
    elif mode == 'list_movies_menu':
        list_movies_menu()
    elif mode == 'list_series_menu':
        list_series_menu()
    elif mode == 'movies_top_rated':
        list_top_rated_movies() 
    elif mode == 'movies_popular':
        list_popular_movies() 
    elif mode == 'movies_now_playing':
        list_now_playing_movies() 
    elif mode == 'movies_genres':
        xbmcgui.Dialog().ok("Filmy: Žánry", "Tato sekce bude brzy implementována.")
        xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'movies_by_year':
        xbmcgui.Dialog().ok("Filmy: Rok", "Tato sekce bude brzy implementována.")
        xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'series_top_rated':
        list_top_rated_series() 
    elif mode == 'series_popular':
        list_popular_series() 
    elif mode == 'series_airing_today':
        list_airing_today_series() 
    elif mode == 'series_genres':
        xbmcgui.Dialog().ok("Seriály: Žánry", "Tato sekce bude brzy implementována.")
        xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'series_by_year':
        xbmcgui.Dialog().ok("Seriály: Rok", "Tato sekce bude brzy implementována.")
        xbmcplugin.endOfDirectory(addon_handle)
    elif mode == 'list_tmdb_series_seasons':
        tmdb_id = params['tmdb_id']
        series_name = params['series_name']
        query_param = params.get('query') # Načtení 'query' parametru
        list_tmdb_series_seasons(int(tmdb_id), series_name, query_param)
    elif mode == 'list_tmdb_season_episodes':
        tmdb_id = params['tmdb_id']
        season_number = params['season_number']
        series_name = params['series_name']
        query_param = params.get('query') # Načtení 'query' parametru
        list_tmdb_season_episodes(int(tmdb_id), int(season_number), series_name, query_param)
    elif mode == 'prompt_tmdb_search':
        media_type = params['media_type']
        prompt_tmdb_search(media_type)
    elif mode == 'tmdb_search_results':
        query = params['query']
        media_type = params['media_type']
        tmdb_search_results(query, media_type)
    else:
        list_main_menu()

if __name__ == '__main__':
    router(sys.argv[2][1:] if len(sys.argv) > 2 else '')
