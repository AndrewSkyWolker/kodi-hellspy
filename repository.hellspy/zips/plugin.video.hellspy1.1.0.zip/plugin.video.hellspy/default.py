import sys
import os
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import json
import re
import unicodedata
from collections import defaultdict

# Dynamický import knihoven ze složky resources/lib
lib_dir = xbmcvfs.translatePath("special://home/addons/plugin.video.hellspy/resources/lib")
sys.path.insert(0, lib_dir)

# IMPORTY po nastavení sys.path
import cloudscraper
from bs4 import BeautifulSoup
import requests

# === Načtení konfigurace z nastavení doplňku ===
addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])

base_url = 'https://www.hellspy.to'
results_per_page = int(addon.getSetting('results_per_page') or 64)
search_history_limit = int(addon.getSetting('search_history_limit') or 10)
watch_history_limit = int(addon.getSetting('watch_history_limit') or 20)
TMDB_API_KEY = addon.getSetting('tmdb_api_key') or ""

# === Cesty k souborům ===
history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/history.txt")
watch_history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history.txt")
cached_results_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/cache.json")

def tmdb_search_title(query):
    try:
        url = f"https://api.themoviedb.org/3/search/multi?api_key={TMDB_API_KEY}&language=cs-CZ&query={urllib.parse.quote(query)}"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
        if data.get("results"):
            for item in data["results"]:
                name = item.get("name") or item.get("title") or item.get("original_name") or item.get("original_title")
                if name:
                    return name  # Vrátí první odpovídající výsledek
    except Exception as e:
        log_debug(f"TMDb API chyba: {e}")
    return None

def log_debug(message):
    xbmc.log(f"[Hellspy DEBUG] {message}", xbmc.LOGINFO)

def save_query_to_history(query, results_count):
    try:
        history_dir = os.path.dirname(history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        history = load_query_history()
        entry = f"{query}|{results_count}"
        history = [h for h in history if not h.startswith(f"{query}|")]
        history.insert(0, entry)
        history = history[:search_history_limit]
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
    except Exception as e:
        log_debug(f"Chyba při zápisu do historie: {e}")

def load_query_history():
    try:
        with open(history_file, "r", encoding="utf-8") as f:
            return [line.strip() for line in f if line.strip()]
    except Exception:
        return []

def delete_query_from_history(query):
    try:
        history = load_query_history()
        history = [h for h in history if not h.startswith(f"{query}|")]
        with open(history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(history))
    except Exception as e:
        log_debug(f"Chyba při mazání z historie: {e}")

# -- HISTORIE SLEDOVÁNÍ --
watch_history_file = xbmcvfs.translatePath("special://profile/addon_data/plugin.video.hellspy/watch_history.txt")

def save_watch_history_entry(video_page_url, title):
    try:
        parsed = urllib.parse.urlparse(video_page_url)
        parts = parsed.path.split('/')
        if len(parts) >= 4 and parts[1] == "video":
            video_id = f"{parts[2]}/{parts[3]}"
        else:
            log_debug(f"Chybný formát URL: {video_page_url}")
            return
        history_dir = os.path.dirname(watch_history_file)
        if not xbmcvfs.exists(history_dir):
            xbmcvfs.mkdirs(history_dir)
        existing = []
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                existing = [line.strip() for line in f if line.strip()]
        entry = f"{video_id}|{title}"
        existing = [e for e in existing if not e.startswith(video_id)]
        existing.insert(0, entry)
        existing = existing[:watch_history_limit]
        with open(watch_history_file, "w", encoding="utf-8") as f:
            f.write("\n".join(existing))
    except Exception as e:
        log_debug(f"Chyba při ukládání historie sledování: {e}")

def load_watch_history_list():
    try:
        if xbmcvfs.exists(watch_history_file):
            with open(watch_history_file, "r", encoding="utf-8") as f:
                return [line.strip().split('|', 1) for line in f if '|' in line]
    except Exception as e:
        log_debug(f"Chyba při načítání historie sledování: {e}")
    return []

def list_watch_history():
    history = load_watch_history_list()
    for video_id, title in history:
        play_url = build_url({'mode': 'play', 'url': f"{base_url}/video/{video_id}"})
        li = xbmcgui.ListItem(label=title)
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(addon_handle)

def build_url(query):
    return sys.argv[0] + '?' + urllib.parse.urlencode(query)

def strong_normalize(name):
    normalized = name.lower()
    normalized = re.sub(r'[\W_]+', ' ', normalized)  # Nahradí vše kromě písmen a čísel mezerou
    normalized = re.sub(r'\s+', ' ', normalized).strip()
    return normalized

def extract_episode_info(title):
    # Odstraň rozsahy a duplicity epizod jako "S01E15-32", "01x03 S01E03", atd.
    title = re.sub(r'(?i)\bS(\d{1,2})E(\d{1,2})[-–]\d{1,2}\b', r'S\1E\2', title)
    title = re.sub(r'\b(S\d{1,2}E\d{1,2})\b.*?\b(\d{1,2}[x\-\.]\d{1,2})\b', r'\1', title, flags=re.IGNORECASE)
    title = re.sub(r'\b(\d{1,2}[x\-\.]\d{1,2})\b.*?\b(S\d{1,2}E\d{1,2})\b', r'\2', title, flags=re.IGNORECASE)

    patterns = [
        
        # SxxExx nebo sxxexx
        r'(?i)(?P<name>.*?)[\s\-_.]*S(?P<season>\d{1,2})E(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01x05 nebo 1x5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})x(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01.05 nebo 1.5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\.(?P<episode>\d{1,2})(?P<extra>.*)',

        # 01-05 nebo 1-5
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})-(?P<episode>\d{1,2})(?P<extra>.*)',

        # 10. série 5. díl
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\.\s*(?:serie|série)[\s\-_.]*(?P<episode>\d{1,2})\.?\s*(?:d[ií]l)?(?P<extra>.*)',

        # série 1 díl 2
        r'(?i)(?P<name>.*?)(?:série|serie)[\s\-_.]*(?P<season>\d{1,2})[\s\-_.]*d[ií]l[\s\-_.]*(?P<episode>\d{1,2})(?P<extra>.*)',

        # 10 série 5 díl
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})\s*(?:série|serie)[\s\-_.]*(?P<episode>\d{1,2})\s*d[ií]l(?P<extra>.*)',
        
        # nový vzor pro 03.-05, 03.05, 03 - 05 apod., ale pouze pokud není následován rokem (kvůli filmům)
        r'(?i)(?P<name>.*?)(?P<season>\d{1,2})[\.\-\s]+(?P<episode>\d{1,2})(?!\d)(?P<extra>.*)',

        # fallback bez sezóny a epizody
        r'(?i)(?P<name>.*?)(?P<extra>.*)'
    ]
    # Pokud je přítomný platný formát SxxExx nebo 01x05, zpracuj jej i přes rok
    for pat in patterns[:-1]:  # vynecháme fallback
        match = re.match(pat, title)
        if match:
            name = match.group("name").strip(" -_.")
            season = match.groupdict().get("season", "01").zfill(2)
            episode = match.groupdict().get("episode", "00").zfill(2)
            extra = match.groupdict().get("extra", "").strip(" -_.")
            return name, season, episode, extra

    # Jinak, pokud je pravděpodobně film (rok), vrať bez epizody
    if re.search(r'\b(19\d{2}|20[0-4]\d|2050)\b', title):
        return title.strip(), "01", "00", ""

    # fallback (něco úplně jiného)
    match = re.match(patterns[-1], title)
    if match:
        name = match.group("name").strip(" -_.")
        extra = match.groupdict().get("extra", "").strip(" -_.")
        return name, "01", "00", extra

    for pat in patterns:
        match = re.match(pat, title)
        if match:
            name = match.group("name").strip(" -_.")
            season = match.groupdict().get("season", "01").zfill(2)
            episode = match.groupdict().get("episode", "00").zfill(2)
            extra = match.groupdict().get("extra", "").strip(" -_.")
            return name, season, episode, extra
    return title.strip(), "01", "00", ""

def list_main_menu():
    url = build_url({'mode': 'search'})
    li = xbmcgui.ListItem(label='Vyhledat')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    url = build_url({'mode': 'history'})
    li = xbmcgui.ListItem(label='Historie hledání')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    url = build_url({'mode': 'watch_history'})
    li = xbmcgui.ListItem(label='Historie sledování')
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.addSortMethod(addon_handle, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(addon_handle, updateListing=False, cacheToDisc=False)

def list_history():
    history = load_query_history()
    for item in history:
        if '|' in item:
            query, count = item.split('|', 1)
        else:
            query, count = item, '?'  # fallback
        search_url = build_url({'mode': 'repeat_search', 'query': query})
        remove_url = build_url({'mode': 'delete_history_item', 'query': query})
        li = xbmcgui.ListItem(label=f"{query} ({count})")
        li.addContextMenuItems([("Smazat z historie", f"RunPlugin({remove_url})")])
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=search_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

def get_html(url):
    scraper = cloudscraper.create_scraper()
    try:
        response = scraper.get(url, timeout=10)
        log_debug(f"GET {url} → Status {response.status_code}")
        return response.text
    except Exception as e:
        log_debug(f"Chyba při spojení: {e}")
        xbmcgui.Dialog().ok("Chyba připojení", "Nepodařilo se spojit se serverem Hellspy.\nZkuste to znovu.")
        raise

def list_search_results(query):
    search_url = f"{base_url}/?query={urllib.parse.quote(query)}"
    html = get_html(search_url)
    soup = BeautifulSoup(html, "html.parser")
    items = soup.select('.result-video')
    results_count = len(items)
    log_debug(f"Nalezeno položek v HTML: {results_count}")
    if results_count == 0:
        xbmcgui.Dialog().ok("Výsledek hledání", f"Pro hledání '{query}' nebyl nalezen žádný výsledek.")
        xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
        return
    seen_titles = set()
    for item in items:
        title = item["title"].strip()
        href = item["href"]
        video_page_url = urllib.parse.urljoin(base_url, href)
        img_tag = item.find("img")
        thumbnail = img_tag["src"] if img_tag else ""
        name, season, episode, extra = extract_episode_info(title)
        # Zachovej původní název, jen normalizuj mezery a oddělovače
        name = re.sub(r'[\.\+\-_]+', ' ', name).strip()
        name = re.sub(r'\s+', ' ', name).strip()
        
        tmdb_name = tmdb_search_title(name)
        if tmdb_name:
            name = tmdb_name

        # Pokud název zůstane prázdný, použij fallback z původního title
        if not name:
            name = title.split()[0]
        # První písmeno velké, zbytek malá (české zachování diakritiky)
        name = name[0].upper() + name[1:] if name else name
        # Zachovej diakritiku a nastav jen první písmeno názvu velké
        name = name.capitalize()
        if season == "01" and episode == "00":
            formatted_title = name.strip().capitalize()
        else:
            formatted_title = f"{name} - S{season}-E{episode}"

        # Odstranění úvodních pomlček a mezer
        formatted_title = re.sub(r'^[\s\-]+', '', formatted_title).strip()

        # Korekce: pokud title začíná malým písmenem, oprav
        if formatted_title and formatted_title[0].islower():
            formatted_title = formatted_title[0].upper() + formatted_title[1:]

        formatted_title = re.sub(r'^[-\s]+', '', formatted_title).strip()
        formatted_title = formatted_title[0].upper() + formatted_title[1:] if formatted_title else formatted_title
        if extra:
            extra = re.sub(r'[\.\+\-_]+', ' ', extra).strip()
            formatted_title += f" - {extra}"
        key = f"{name.lower()}_s{season}_e{episode}"
        if key in seen_titles:
            continue
        seen_titles.add(key)
        li = xbmcgui.ListItem(label=formatted_title)
        li.setArt({"thumb": thumbnail, "icon": thumbnail, "poster": thumbnail})
        li.setInfo("video", {"title": formatted_title})
        li.setProperty("IsPlayable", "true")
        play_url = build_url({'mode': 'play', 'url': video_page_url})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=play_url, listitem=li, isFolder=False)
    save_query_to_history(query, results_count)
    xbmcplugin.endOfDirectory(addon_handle)
    log_debug("Zavolání endOfDirectory (garantováno)")

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get('mode')
    if mode == 'search':
        xbmcplugin.endOfDirectory(addon_handle, updateListing=False)
        keyboard = xbmcgui.Dialog().input("Zadejte hledaný výraz", type=xbmcgui.INPUT_ALPHANUM)
        if keyboard:
            xbmc.executebuiltin(f"Container.Update({build_url({'mode': 'repeat_search', 'query': keyboard})})")
        else:
            xbmc.executebuiltin("Container.Update(plugin://plugin.video.hellspy/)")
    elif mode == 'repeat_search':
        list_search_results(params['query'])
    elif mode == 'delete_history_item':
        delete_query_from_history(params['query'])
        xbmc.executebuiltin(f"Container.Refresh")
    elif mode == 'history':
        list_history()
    elif mode == 'watch_history':
        list_watch_history()
    elif mode == 'play':
        play_video(params['url'])
    else:
        list_main_menu()

def play_video(url):
    html = get_html(url)
    matches = re.findall(r'self\.__next_f\.push\(\[1,"(.*?)"\]\)', html)
    for raw_string in matches:
        try:
            decoded_str = bytes(raw_string, "utf-8").decode("unicode_escape")
            if '"initialVideo":{' in decoded_str:
                match = re.search(r'"initialVideo"\s*:\s*(\{.*?\})\s*,\s*"initialVideoId"', decoded_str, re.DOTALL)
                if not match:
                    continue
                video_json = json.loads(match.group(1))
                conversions = video_json.get("conversions", {})
                video_url = conversions.get("1080") or conversions.get("720")
                if not video_url:
                    xbmcgui.Dialog().ok("Chyba", "Nepodařilo se najít streamovací odkaz.")
                    return
                log_debug(f"Streamovací URL: {video_url}")
                title = video_json.get("title", "Neznámý název")
                save_watch_history_entry(url, title)
                listitem = xbmcgui.ListItem(path=video_url)
                listitem.setMimeType("video/mp4")
                listitem.setProperty("IsPlayable", "true")
                listitem.setContentLookup(False)
                xbmcplugin.setResolvedUrl(addon_handle, True, listitem)
                return
        except Exception as e:
            log_debug(f"Chyba při dekódování nebo JSON parse: {e}")
            continue

    log_debug("Nepodařilo se najít validní JSON s initialVideo.")
    xbmcgui.Dialog().ok("Chyba", "Nepodařilo se získat data o videu.")

router(sys.argv[2][1:] if len(sys.argv) > 2 else '')